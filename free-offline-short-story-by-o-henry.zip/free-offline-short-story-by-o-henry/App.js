import * as React from 'react';
import { ScrollView, Text, View, StyleSheet, ButtonGroup} from 'react-native';
import { Constants } from 'expo';
import { Button, Header } from 'react-native-elements'
import Homepage from './components/Homepage'
import Story1 from './components/Story1'
import Story2 from './components/Story2'
import Story3 from './components/Story3'
import Story4 from './components/Story4'
import Story5 from './components/Story5'
import Story6 from './components/Story6'
import Story7 from './components/Story7'
import Story8 from './components/Story8'
import Story9 from './components/Story9'
import Story10 from './components/Story10'
import Story11 from './components/Story11'
import Story12 from './components/Story12'
import Story13 from './components/Story13'
import Story14 from './components/Story14'
import Story15 from './components/Story15'
import Info from './components/Info'
import AssetExample from './components/AssetExample';
import { Card } from 'react-native-paper';
import {DrawerNavigator, createStackNavigator, createAppContainer} from 'react-navigation';

const MainNavigator = createStackNavigator({
  Homepage: {screen: Homepage},
  Info: {screen: Info},
  Story1: {screen: Story1},
  Story2: {screen: Story2},
  Story3: {screen: Story3},
  Story4: {screen: Story4},
  Story5: {screen: Story5},
  Story6: {screen: Story6},
  Story7: {screen: Story7},
  Story8: {screen: Story8},
  Story9: {screen: Story9},
  Story10: {screen: Story10},
  Story11: {screen: Story11},
  Story12: {screen: Story12},
  Story13: {screen: Story13},
  Story14: {screen: Story14},
  Story15: {screen: Story15},
});

const App = createAppContainer(MainNavigator);

export default App;




// const App = DrawerNavigator({
//   Homepage: {screen: Homepage},
//   Info: {screen: Info},
//   Story1: {screen: Story1},
//   Story2: {screen: Story2},
//   Story3: {screen: Story3},
//   Story4: {screen: Story4},
//   Story5: {screen: Story5},
//   Story6: {screen: Story6},
//   Story7: {screen: Story7},
//   Story8: {screen: Story8},
//   Story9: {screen: Story9},
//   Story10: {screen: Story10},
//   Story11: {screen: Story11},
//   Story12: {screen: Story12},
//   Story13: {screen: Story13},
//   Story14: {screen: Story14},
//   Story15: {screen: Story15},
// });


// export default App;