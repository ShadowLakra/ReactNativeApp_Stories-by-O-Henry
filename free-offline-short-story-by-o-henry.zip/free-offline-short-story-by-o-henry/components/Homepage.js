import * as React from 'react';
import {ScrollView, TouchableOpacity, Text, View, StyleSheet, ButtonGroup} from 'react-native';
import { Button, Header, Icon } from 'react-native-elements'
import { Card } from 'react-native-paper';
import Ad from './Ad'

export default class Homepage extends React.Component {

  static navigationOptions = {
    title: 'Home',
    // title: null,
    header: null,
  };
  render() {
    const {navigate} = this.props.navigation;
    return (
      <ScrollView>
      <View style={styles.container}>
      <Ad />
      <Header
        // leftComponent={{ icon: 'menu', color: '#fff' }}
        centerComponent={{ text: 'Short Stories by O Henry', style: { color: '#fff' } }}
        // rightComponent={{ icon: 'info', color: '#fff', onPress:{() => navigate('Info')} }}
        rightComponent={
          <Icon
            name = 'info'
            color = '#fff'
            onPress = {() => navigate('Info')} />
        }
      />

        
  <Card>
        <Button
          onPress={() => navigate('Story1')}
          title="The Gift of the Magi"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story2')}
          title="A Cosmopolite in a Café"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story3')}
          title="Between Rounds"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story4')}
          title="The Skylight Room"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story5')}
          title="A Service of Love"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story6')}
          title="The Coming-Out of Maggie "
          type="outline"
        />
        <Button
          onPress={() => navigate('Story7')}
          title="The Cop and the Anthem"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story8')}
          title="Memoirs of a Yellow Dog"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story9')}
          title="The Love-philtre of Ikey Shoenstein"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story10')}
          title="The Furnished Room"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story11')}
          title="The Last Leaf"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story12')}
          title="The Poet and the Peasant"
          type="outline"
        />
        <Button
          onPress={() => navigate('Story13')}
          title="A Ramble in Aphasia"
          type="outline"
        />
         <Button
          onPress={() => navigate('Story14')}
          title="A Municipal Report"
          type="outline"
        />
         <Button
          onPress={() => navigate('Story15')}
          title="Proof of the Pudding"
          type="outline"
        />
        </Card>
        
      </View>
      </ScrollView>
    );
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    // paddingTop: Constants.statusBarHeight,
    backgroundColor: '#00f000',
    padding: 8,
  },

});