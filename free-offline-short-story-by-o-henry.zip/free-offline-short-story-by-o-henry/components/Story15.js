import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import Ad from './Ad'
import styles from './styles'
import { LinearGradient } from 'expo';


export default class Story15 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>

      <Ad />

      <View style={styles.container}>

      
       <LinearGradient colors={styles.linearGradient.colors} >
       <Text style={styles.storyTitle}>
          Proof of the Pudding
       </Text>

        <Text style={styles.paragraph}>


SPRING WINKED a vitreous optic at Editor Westbrook, of the Min­
erva Magazine, and deflected him from his course. He had lunched
in his favourite corner of a Broadway hotel, and was returning to
his office when his feet became entangled in the lure of the vernal
coquette. Which is by way of saying that he turned eastward in
Twenty-sixth Street, safely forded the spring freshet of vehicles in
Fifth Avenue, and meandered along the walks of budding Madison
Square.{"\n"}{"\n"}
The lenient air and the settings of the little park almost formed
a pastoral; the colour motif was green - the presiding shade at the
creation of man and vegetation.{"\n"}{"\n"}
The callow grass between the walks was the colour of verdigris,
a poisonous green, reminiscent of the horde of derelict humans
that had breathed upon the soil during the summer and autumn.{"\n"}{"\n"}
The bursting tree-buds looked strangely familiar to those who had
botanized among the garnishings of the fish course of a forty-cent
dinner. The sky above was of that pale aquamarine tint that hallroom poets rhyme with 'true' and 'Sue' and 'coo.' The one natural
and frank colour visible was the ostensible green of the newly
painted benches - a shade between the colour of a pickled cucum­
ber and that of a last year's fast-back cravenette raincoat. But, to
the city-bred eye of Editor Westbrook, the landscape appeared a
masterpiece.{"\n"}{"\n"}
And now, whether you are of those who rush in, or of the gentle
concourse that fears to tread, you must follow in a brief invasion
of the editor's mind.{"\n"}{"\n"}
Editor Westbrook's spirit was contented and serene. The April
number of the Minerva had sold its entire edition before the tenth
day of the month - a newsdealer in Keokuk had written that he
could have sold fifty copies more if he had had 'em. The owners of
the magazine had raised his (the editor's) salary; he had just
installed in his home a jewel of a recently imported cook who was
afraid of policemen; and the morning papers had published in full
a speech he had made at a publishers' banquet. Also there were
echoing in his mind the jubilant notes of a splendid song that his
charming young wife had sung to him before he left his uptown
apartment that morning. She was taking enthusiastic interest in
her music of late, practising early and diligently. When he had
complimented her on the improvement in her voice she had fairly
hugged him for joy at his praise. He felt, too, the benign, tonic
medicament of the trained nurse, Spring, tripping softly adown
the wards of the convalescent city.{"\n"}{"\n"}
While Editor Westbrook was sauntering between rows of park
benches (already filling with vagrants and the guardians of lawless
childhood) he felt his sleeve grasped and held. Suspecting that he
was about to be panhandled, he turned a cold and unprofitable
face, and saw that his captor was - Dawe - Shackleford Dawe,
dingy, almost ragged, the genteel scarcely visible in him through
the deeper lines of the shabby.{"\n"}{"\n"}
While the editor is pulling himself out of his surprise, a flash­
light biography of Dawe is offered.{"\n"}{"\n"}
He was a fiction writer, and one of Westbrook's old acquain­
tances. At one time they might have called each other old friends.{"\n"}{"\n"}
Dawe had some money in those days, and lived in a decent apart­
ment-house near Westbrook's. The two families often went to
theatres and dinners together. Mrs. Dawe and Mrs. Westbrook
became 'dearest' friends. Then one day a little tentacle of the
octopus, just to amuse itself, ingurgitated Dawe's capital, and he
moved to the Gramercy Park neighbourhood, where one, for a
few groats per week, may sit upon one's trunk under eightbranched chandeliers and opposite Carrara marble mantels and
watch the mice play upon the floor. Dawe thought to live by writ­
ing fiction. Now and then he sold a story. He submitted many to
Westbrook. The Minerva printed one or two of them; the rest
were returned. Westbrook sent a careful and conscientious per­
sonal letter with each rejected manuscript, pointing out in detail
his reasons for considering it unavailable. Editor Westbrook had
his own clear conception of what constituted good fiction. So had
Dawe. Mrs. Dawe was mainly concerned about the constituents
of the scanty dishes of food that she managed to scrape together.{"\n"}{"\n"}
One day Dawe had been spouting to her about the excellences
of certain French writers. At dinner they sat down to a dish that
a hungry schoolboy could have encompassed at a gulp. Dawe
commented.{"\n"}{"\n"}
'It's Maupassant hash,' said Mrs. Dawe. 'It may not be art, but I
do wish you would do a five course Marion Crawford serial with
an Ella Wheeler Wilcox sonnet for dessert. I'm hungry.'{"\n"}
As far as this from success was Shackleford Dawe when he
plucked Editor Westbrook's sleeve in Madison Square. That was
the first time the editor had seen Dawe in several months.{"\n"}{"\n"}
'Why, Shack, is this you?' said Westbrook somewhat awk­
wardly, for the form of this phrase seemed to touch upon the
other's changed appearance.{"\n"}{"\n"}
'Sit down for a minute,' said Dawe, tugging at his sleeve. 'This
is my office. I can't come to yours, looking as I do. Oh, sit down you won't be disgraced. Those half-plucked birds on the other
benches will take you for a swell porch-climber. They won't know
you are only an editor.'{"\n"}
'Smoke, Shack?' said Editor Westbrook, sinking cautiously
upon the virulent green bench. He always yielded gracefully when
he did yield.{"\n"}{"\n"}
Dawe snapped at the cigar as a kingfisher darts at a sunperch, or
a girl pecks at a chocolate cream.{"\n"}{"\n"}
'I have just- ' began the editor.{"\n"}{"\n"}
'Oh, I know; don't finish,' said Dawe. 'Give me a match. You
have just ten minutes to spare. How did you manage to get past
my office-boy and invade my sanctum? There he goes now,
throwing his club at a dog that couldn't read the "Keep off the
Grass" signs.'"{"\n"}
'How goes the writing?' asked the editor.{"\n"}{"\n"}
'Look at me,' said Dawe, 'for your answer. Now don't put on
that embarrassed, friendly-but-honest look and ask me why I
don't get a job as a wine agent or a cab-driver. I'm in the fight to
a finish. I know I can write good fiction and I'll force you fellows
to admit it yet. I'll make you change the spelling of "regrets" to
"c-h-e-q-u-e" before I'm done with you.'{"\n"}
Editor Westbrook gazed through his nose-glasses with a sweetly
sorrowful, omniscient, sympathetic, sceptical expression - the
copyrighted expression of the editor beleaguered by the unavailable
contributor.{"\n"}{"\n"}
'Have you read the last story I sent you - "The Alarum of the
Soul"?' asked Dawe." {"\n"}{"\n"}
'Carefully. I hesitated over that story, Shack, really I did. It had
some good points. I was writing you a letter to send with it when
it goes back to you. I regret- '
'Never mind the regrets,' said Dawe grimly. 'There's neither
salve nor sting in 'em any more. What I want to know is why.{"\n"}{"\n"}
Come, now; out with the good points first.'{"\n"}
'The story,' said Westbrook deliberately, after a suppressed
sigh, 'is written around an almost original plot. Characterization the best you have done. Construction - almost as good, except for
a few weak joints which might be strengthened by a few changes
and touches. It was a good story, except- '
'I can write English, can't I?' interrupted Dawe.{"\n"}{"\n"}
'I have always told you,' said the editor, 'that you had a style.'{"\n"}
'Then the trouble is the- '
'Same old thing,' said Editor Westbrook. 'You work up to your
climax like an artist. And then you turn yourself into a photogra­
pher. I don't know what form of obstinate madness possesses you,
Shack, but that is what you do with everything that you write.{"\n"}{"\n"}
No, I will retract the comparison with the photographer. Now
and then photography, in spite of its impossible perspective, man­
ages to record a fleeting glimpse of truth. But you spoil every
denouement by those flat, drab, obliterating strokes of your brush
that I have so often complained of. If you would rise to the liter­
ary pinnacle of your dramatic scenes, and paint them in the high
colours that art requires, the postman would leave fewer bulky,
self-addressed envelopes at your door.'{"\n"}
'Oh, fiddles and footlights!' cried Dawe derisively. 'You've got
that old sawmill drama kink in your brain yet. When the man with
the black moustache kidnaps golden-haired Bessie you are bound
to have the mother kneel and raise her hands in the spotlight and
say: "May high heaven witness that I will rest neither night nor
day till the heartless villain that has stolen me child feels the
weight of a mother's vengeance!" '
Editor Westbrook conceded a smile of impervious complacency.{"\n"}{"\n"}
'I think,' said he, 'that in real life the woman would express her­
self in those words or in very similar ones.'{"\n"}
'Not in a six hundred nights' run anywhere but on the stage,'
said Dawe hotly. 'I'll tell you what she'd say in real life. She'd say:
"What! Bessie led away by a strange man? Good Lord! It's one
trouble after another! Get my other hat, I must hurry around to
the police-station. Why wasn't somebody looking after her, I'd
like to know? For God's sake, get out of my way or I'll never get
ready. Not that hat - the brown one with the velvet bows. Bessie
must have been crazy; she's usually shy of strangers. Is that too
much powder? Lordy! How I'm upset!"
'That's the way she'd talk,' continued Dawe. 'People in real life
don't fly into heroics and blank verse at emotional crises. They
simply can't do it. If they talk at all on such occasions they draw
from the same vocabulary that they use every day, and muddle up
their words and ideas a little more, that's all.'{"\n"}
'Shack,' said Editor Westbrook impressively, 'did you ever pick
up the mangled and lifeless form of a child from under the fender
of a street-car, and carry it in your arms and lay it down before the
distracted mother? Did you ever do that and listen to the words of
grief and despair as they flowed spontaneously from her lips?'
'I never did,' said Dawe. 'Did you?'
'Well, no,' said Editor Westbrook, with a slight frown. 'But I
can well imagine what she would say.'{"\n"}
'So can I,' said Dawe.{"\n"}{"\n"}
And now the fitting time had come for Editor Westbrook to play
the oracle and silence his opinionated contributor. It was not for an
unarrived fictionist to dictate words to be uttered by the heroes and
heroines of the Minerva Magazine, contrary to the theories of the
editor thereof.{"\n"}{"\n"}
'My dear Shack,' said he, 'if I know anything of life I know that
every sudden, deep and tragic emotion in the human heart calls
forth an apposite, concordant, conformable, and proportionate
expression of feeling? How much of this inevitable accord between
expression and feeling should be attributed to nature, and how
much to the influence of art, it would be difficult to say. The sub­
limely terrible roar of the lioness that has been deprived of her
cubs is dramatically as far above her customary whine and purr as
the kingly and transcendent utterances of Lear are above the level
of his senile vapourings. But it is also true that all men and women
have what may be called a subconscious dramatic sense that is
awakened by a sufficiently deep and powerful emotion - a sense
unconsciously acquired from literature and the stage that prompts
them to express those emotions in language befitting their impor­
tance and histrionic value.'{"\n"}
'And in the name of seven sacred saddle-blankets of Sagittarius,
where did the stage and literature get the stunt?' asked Dawe.{"\n"}{"\n"}
'From life,' answered the editor triumphantly.{"\n"}{"\n"}
The story-writer rose from the bench and gesticulated elo­
quently but dumbly. He was beggared for words with which to
formulate adequately his dissent.{"\n"}{"\n"}
On a bench near by a frowsy loafer opened his red eyes and
perceived that his moral support was due to a down-trodden
brother.{"\n"}{"\n"}
'Punch him one, Jack,' he called hoarsely to Dawe. ' W a t ' s he
come makin' a noise like a penny arcade for amongst gen'lemen
that comes in the Square to set and think?'
Editor Westbrook looked at his watch with an affected show of
leisure.{"\n"}{"\n"}
'Tell me,' asked Dawe, with truculent anxiety, 'what especial
faults in "The Alarum of the Soul" caused you to throw it down.'{"\n"}
'When Gabriel Murray,' said Westbrook, 'goes to his telephone
and is told that his fiancee has been shot by a burglar, he says - I
do not recall the exact words, but- '
'I do,' said Dawe. 'He says: "Damn Central; she always cuts me
off." (And then to his friend): "Say, Tommy, does a thirty-two
bullet make a big hole? It's kind of hard luck, ain't it? Could you
get me a drink from the sideboard, Tommy? No; straight; nothing
on the side." '
'And again,' continued the editor, without pausing for argu­
ment, 'when Berenice opens the letter from her husband inform­
ing her that he has fled with the manicure girl, her words are - let
me see- '
'She says,' interposed the author: ' "Well, what do you think of
that!" '
'Absurdly inappropriate words,' said Westbrook, 'presenting
an anti-climax - plunging the story into hopeless bathos. Worse
yet; they mirror life falsely. No human being ever uttered banal
colloquialisms when confronted by sudden tragedy.'{"\n"}
'Wrong,' said Dawe, closing his unshaven jaws doggedly. 'I say
no man or woman ever spouts highfalutin talk when they go up
against a real climax. They talk naturally, and a little worse.'{"\n"}
The editor rose from the bench with his air of indulgence and
inside information.{"\n"}{"\n"}
'Say, Westbrook,' said Dawe, pinning him by the lapel, 'would
you have accepted "The Alarum of the Soul" if you had believed
that the actions and words of the characters were true to life in the
parts of the story that we discussed?'
'It is very likely that I would, if I believed that way,' said the
editor. 'But I have explained to you that I do not.'{"\n"}
'If I could prove to you that I am right?'
'I'm sorry, Shack, but I'm afraid I haven't time to argue any
further just now.'{"\n"}
'I don't want to argue,' said Dawe. 'I want to demonstrate to
you from life itself that my view is the correct one.'{"\n"}
'How could you do that?' asked Westbrook in a surprised tone.{"\n"}{"\n"}
'Listen,' said the writer seriously. 'I have thought of a way. It is
important to me that my theory of true-to-life fiction be recog­
nized as correct by the magazines. I've fought for it for three
years, and I'm down to my last dollar, with two months' rent due.'{"\n"}
'I have applied the opposite of your theory,' said the editor, 'in
selecting the fiction for the Minerva Magazine. The circulation has
gone up from ninety thousand to- '
'Four hundred thousand,' said Dawe. 'Whereas it should have
been boosted to a million.'{"\n"}
'You said something to me just now about demonstrating your
pet theory.'{"\n"}
'I will. If you'll give me about half an hour of your time I'll
prove to you that I am right. I'll prove it by Louise.'{"\n"}
'Your wife!' exclaimed Westbrook. 'How?'
'Well, not exactly by her, but with her,' said Dawe. 'Now, you
know how devoted and loving Louise has always been. She thinks
I'm the only genuine preparation on the market that bears the old
doctor's signature. She's been fonder and more faithful than ever,
since I've been cast for the neglected genius part.'{"\n"}
'Indeed, she is a charming and admirable life companion,'
agreed the editor. 'I remember what inseparable friends she and
Mrs. Westbrook once were. W e are both lucky chaps, Shack, to
have such wives. You must bring Mrs. Dawe up some evening
soon, and we'll have one of those informal chafing-dish suppers
that we used to enjoy so much.'{"\n"}
'Later,' said Dawe. 'When I get another shirt. And now I'll tell
you my scheme. When I was about to leave home after breakfast if you can call tea and oatmeal breakfast - Louise told me she was
going to visit her aunt in Eighty-ninth Street. She said she would
return home at three o'clock. She is always on time to a minute. It
is now- '
Dawe glanced toward the editor's watch pocket.{"\n"}{"\n"}
'Twenty-seven minutes to three,' said Westbrook, scanning his
timepiece.{"\n"}{"\n"}
'We have just enough time,' said Dawe. 'We will go to my flat
at once. I will write a note, address it to her and leave it on the
table where she will see it as she enters the door. You and I will be
in the dining-room concealed by the portieres. In that note I'll say
that I have fled from her for ever with an affinity who understands
the needs of my artistic soul as she never did. When she reads it
we will observe her actions and hear her words. Then we will
know which theory is the correct one - yours or mine.'{"\n"}
'Oh, never!' exclaimed the editor, shaking his head. 'That would
be inexcusably cruel. I could not consent to have Mrs. Dawe's
feelings played upon in such a manner.'{"\n"}
'Brace up,' said the writer. 'I guess I think as much of her as you
do. It's for her benefit as well as mine. I've got to get a market for
my stories in some way. It won't hurt Louise. She's healthy and
sound. Her heart goes as strong as a ninety-eight-cent watch. It'll
last for only a minute, and then I'll step out and explain to her.{"\n"}{"\n"}
You really owe it to me to give me the chance, Westbrook.'{"\n"}
Editor Westbrook at length yielded, though but half willingly.{"\n"}{"\n"}
And in the half of him that consented lurked the vivisectionist that
is in all of us.{"\n"}{"\n"}
Let him who has not used the scalpel rise and stand in his place.{"\n"}{"\n"}
Pity 'tis that there are not enough rabbits and guinea-pigs to go
around.{"\n"}{"\n"}
The two experimenters in Art left the Square and hurried east­
ward and then to the south until they arrived in the Gramercy
neighbourhood. Within its high iron railings the little park had put
on its smart coat of vernal green, and was admiring itself in its foun­
tain minor. Outside the railings the hollow square of crumbling
houses, shells of a bygone gentry, leaned as if in ghostly gossip over
the forgotten doings of the vanished quality. Sic transit gloria urbis.{"\n"}{"\n"}
A block or two north of the Park, Dawe steered the editor again
eastward, then, after covering a short distance, into a lofty but
narrow flathouse burdened with a floridly over-decorated facade.{"\n"}{"\n"}
To the fifth story they toiled, and Dawe, panting, pushed his
latch-key into the door of one of the front flats.{"\n"}{"\n"}
When the door opened Editor Westbrook saw, with feelings of
pity, how meanly and meagrely the rooms were furnished.{"\n"}{"\n"}
'Get a chair, if you can find one,' said Dawe, 'while I hunt up
pen and ink. Hallo, what's this? Here's a note from Louise. She
must have left it there when she went out this morning.'{"\n"}
He picked up an envelope that lay on the centre-table and tore
it open. He began to read the letter that he drew out of it; and
once having begun it aloud he so read it through to the end.{"\n"}{"\n"}
These are the words that Editor Westbrook heard:
DEAR SHACKLEFORD, -

'By the time you get this I will be about a hundred miles away
and still a-going. I've got a place in the chorus of the Occidental
Opera Co., and we start on the road to-day at twelve o'clock. I
didn't want to starve to death, and so I decided to make my own
living. I'm not coming back. Mrs. Westbrook is going with me.{"\n"}{"\n"}
She said she was tired of living with a combination phonograph,
iceberg and dictionary, and she's not coming back, either. We've
been practising the songs and dances for two months on the quiet.{"\n"}{"\n"}
I hope you will be successful, and get along all right. Good-bye.{"\n"}{"\n"}
'LOUISE.'{"\n"}

Dawe dropped the letter, covered his face with his trembling
hands, and cried out in a deep vibrating voice:
'My God, why hast Thou given me this cup to drink? Since she is
false, then let Thy Heaven's fairest gifts, faith and love, become the
jesting bywords of traitors and friends!'
Editor Westbrook's glasses fell to the floor. The fingers of one
hand fumbled with a button on his coat as he blurted between his
pale lips:



'Say, Shack, ain't that a hell of a note? Wouldn't that knock you off your perch, Shack? Ain't it hell, now, Shack - ain't it?' {"\n"}{"\n"}
        </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}