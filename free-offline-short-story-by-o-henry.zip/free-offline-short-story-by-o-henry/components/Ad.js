import * as React from 'react';
import { AdMobBanner, AdMobInterstitial, PublisherBanner, AdMobRewarded} from 'expo';
import {ScrollView } from 'react-native';


export default class Ad extends React.Component {
  render() {
    return (
      <AdMobBanner
          bannerSize="fullBanner"
          // adUnitID="ca-app-pub-3940256099942544/6300978111" // Test ID, Replace with your-admob-unit-id
          adUnitID="ca-app-pub-2185703755908035/2355828460" //my Ad from shadow
          // adUnitID="pub-2185703755908035"
          testDeviceID="EMULATOR"
          onDidFailToReceiveAdWithError={this.bannerError} />
        
    );
  }
}