import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import { Actions, Router, Scene } from "react-native-router-flux";
import styles from './styles'
import { LinearGradient } from 'expo';
import Ad from './Ad'

export default class Story4 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
        <LinearGradient colors={styles.linearGradient.colors} >
        <Text style={styles.storyTitle}>
          The Skylight Room
       </Text>
        <Text style={styles.paragraph}>
          
FIRST M R S . PARKER would show you the double parlours. You
would not dare to interrupt her description of their advantages
and of the merits of the gentleman who had occupied them for
eight years. Then you would manage to stammer forth the confes­
sion that you were neither a doctor nor a dentist. Mrs. Parker's
manner of receiving the admission was such that you could never
afterward entertain the same feeling toward your parents, who had
neglected to train you up in one of the professions that fitted Mrs.{"\n"}{"\n"}
Parker's parlours.{"\n"}{"\n"}
Next you ascended one flight of stairs and looked at the second
floor back at $8. Convinced by her second-floor manner that it
was worth the $12 that Mr. Toosenberry always paid for it until
he left to take charge of his brother's orange plantation in Florida
near Palm Beach, where Mrs. McIntyre always spent the winters
that had the double front room with private bath, you managed to
babble that you wanted something still cheaper.{"\n"}{"\n"}
If you survived Mrs. Parker's scorn, you were taken to look at
Mr. Skidder's large hall-room on the third floor. Mr. Skidder's
room was not vacant. He wrote plays and smoked cigarettes in it
all day long. But every room-hunter was made to visit his room to
admire the lambrequins. After each visit, Mr. Skidder, from the
fright caused by possible eviction, would pay something on his
rent.{"\n"}{"\n"}
Then - oh, then - if you still stood on one foot with your hot
hand clutching the three moist dollars in your pocket, and
hoarsely proclaimed your hideous and culpable poverty, never­
more would Mrs. Parker be cicerone of yours. She would honk
loudly the word 'Clara,' she would show you her back, and march
downstairs. Then Clara, the coloured maid, would escort you up
the carpeted ladder that served for the fourth flight, and show you
the Skylight Room. It occupied 7 by 8 feet of floorspace at the
middle of the hall. On each side of it was a dark lumber closet or
store-room.{"\n"}{"\n"}
In it was an iron cot, a washstand and a chair. A shelf was the
dresser. Its four bare walls seemed to close in upon you like the
sides of a coin. Your hand crept to your throat, you gasped, you
looked up as from a well - and breathed once more. Through the
glass of the little skylight you saw a square of blue infinity.{"\n"}{"\n"}
'Two dollars, suh,' Clara would say in her half-contemptuous,
half-Tuskegeenial tones.{"\n"}{"\n"}
One day Miss Leeson came hunting for a room. She carried a
typewriter made to be lugged around by a much larger lady. She
was a very little girl, with eyes and hair that kept on growing after
she had stopped and that always looked as if they were saying:
'Goodness me. W h y didn't you keep up with us?'
Mrs. Parker showed her the double parlours. 'In this closet,' she
said, 'one could keep a skeleton or anaesthetic or coal - '
'But I am neither a doctor nor a dentist,' said Miss Leeson with
a shiver.{"\n"}{"\n"}
Mrs. Parker gave her the incredulous, pitying, sneering, icy
stare that she kept for those who failed to qualify as doctors or
dentists, and led the way to the second floor back.{"\n"}{"\n"}
'Eight dollars?' said Miss Leeson. 'Dear me! I'm not Hetty if I
do look green. I'm just a poor little working girl. Show me some­
thing higher and lower.'{"\n"}
Mr. Skidder jumped and strewed the floor with cigarette stubs
at the rap on his door.{"\n"}{"\n"}
'Excuse me, Mr. Skidder,' said Mrs. Parker, with her demon's
smile at his pale looks. 'I didn't know you were in. I asked the lady
to have a look at your lambrequins.'{"\n"}
'They're too lovely for anything,' said Miss Leeson, smiling in
exactly the way the angels do.{"\n"}{"\n"}
After they had gone Mr. Skidder got very busy erasing the
tall, black-haired heroine from his latest (unproduced) play and
inserting a small, roguish one with heavy, bright hair and vivacious
features.{"\n"}{"\n"}
'Anna Held'll jump at it,' said Mr. Skidder to himself, putting
his feet up against the lambrequins and disappearing in a cloud of
smoke like an aerial cuttlefish.{"\n"}{"\n"}
Presently the tocsin call of 'Clara!' sounded to the world the
state of Miss Leeson's purse. A dark goblin seized her, mounted
a Stygian stairway, thrust her into a vault with a glimmer of light
in its top and muttered the menacing and cabalistic words 'Two
dollars!'
'I'll take it!' sighed Miss Leeson, sinking down upon the
squeaky iron bed.{"\n"}{"\n"}
Every day Miss Leeson went out to work. At night she brought
home papers with handwriting on them and made copies with her
typewriter. Sometimes she had no work at night, and then she
would sit on the steps of the high stoop with the other roomers.{"\n"}{"\n"}
Miss Leeson was not intended for a skylight room when the plans
were drawn for her creation. She was gay-hearted and full of
tender, whimsical fancies. Once she let Mr. Skidder read to her
three acts of his great (unpublished) comedy, 'It's No Kid; or, The
Heir of the Subway.'{"\n"}
There was rejoicing among the gentlemen roomers whenever
Miss Leeson had time to sit on the steps for an hour or two. But
Miss Longnecker, the tall blonde who taught in a public school
and said 'Well, really!' to everything you said, sat on the top step
and sniffed. And Miss Dorn, who shot at the moving ducks at
Coney every Sunday and worked in a department store, sat on the
bottom step and sniffed. Miss Leeson sat on the middle step, and
the men would quickly group around her.{"\n"}{"\n"}
Especially Mr. Skidder, who had cast her in his mind for the
star part in a private, romantic (unspoken) drama in real life. And
especially Mr. Hoover, who was forty-five, fat, flushed and foolish.{"\n"}{"\n"}
And especially very young Mr. Evans, who set up a hollow cough
to induce her to ask him to leave off cigarettes. The men voted her
'the funniest and jolliest ever,' but the sniffs on the top step and
the lower step were implacable.{"\n"}{"\n"}

I pray you let the drama halt while Chorus stalks to the foot­
lights and drops an epicedian tear upon the fatness of Mr. Hoover.{"\n"}{"\n"}
Tune the pipes to the tragedy of tallow, the bane of bulk, the
calamity of corpulence. Tried out, Falstaff might have rendered
more romance to the ton than would have Romeo's rickety ribs to
the ounce. A lover may sigh, but he must not puff. To the train of
Momus are the fat men remanded. In vain beats the faithfullest
heart above a 52-inch belt. Avaunt, Hoover! Hoover, forty-five,
flush and foolish, might carry off Helen herself; Hoover, fortyfive, flush, foolish and fat, is meat for perdition. There was never a
chance for you, Hoover.{"\n"}{"\n"}
As Mrs. Parker's roomers sat thus one summer's evening, Miss
Leeson looked up into the firmament and cried with her little gay
laugh:
'Why, there's Billy Jackson! I can see him from down here, too.'{"\n"}
All looked up - some at the windows of skyscrapers, some cast­
ing about for an airship, Jackson-guided.{"\n"}{"\n"}
'It's that star,' explained Miss Leeson, pointing with a tiny
finger. 'Not the big one that twinkles - the steady blue one near it.{"\n"}{"\n"}
I can see it every night through my skylight. I named it Billy Jack­
son.'{"\n"}
'Well, really!' said Miss Longnecker. 'I didn't know you were an
astronomer, Miss Leeson.'{"\n"}
'Oh, yes,' said the small star-gazer, 'I know as much as any of
them about the style of sleeves they're going to wear next fall in
Mars.'{"\n"}
'Well, really!' said Miss Longnecker. 'The star you refer to is
Gamma, of the constellation Cassiopeia. It is nearly of the second
magnitude, and its meridian passage is - '
'Oh,' said the very young Mr. Evans, 'I think Billy Jackson is a
much better name for it.{"\n"}{"\n"}
'Same here,' said Mr. Hoover, loudly breathing defiance to Miss
Longnecker. 'I think Miss Leeson has just as much right to name
stars as any of those old astrologers had.'{"\n"}
'Well, really!' said Miss Longnecker.{"\n"}{"\n"}
'I wonder whether it's a shooting star,' remarked Miss Dorn. 'I
hit nine ducks and a rabbit out of ten in the gallery at Coney
Sunday.'{"\n"}
'He doesn't show up very well from down here,' said Miss
Leeson. 'You ought to see him from my room. You know you can
see stars even in the daytime from the bottom of a well. At night
my room is like the shaft of a coal-mine, and it makes Billy Jackson
look like the big diamond pin that Night fastens her kimono with.'{"\n"}
There came a time after that when Miss Leeson brought no for­
midable papers home to copy. And when she went in the morning,
instead of working, she went from office to office and let her heart
melt away in the drip of cold refusals transmitted through insolent
office boys. This went on.{"\n"}{"\n"}
There came an evening when she wearily climbed Mrs. Parker's
stoop at the hour when she always returned from her dinner at the
restaurant. But she had had no dinner.{"\n"}{"\n"}
As she stepped into the hall Mr. Hoover met her and seized his
chance. He asked her to marry him, and his fatness hovered above
her like an avalanche. She dodged, and caught the balustrade. He
tried for her hand, and she raised it and smote him weakly in the
face. Step by step she went up, dragging herself by the railing.{"\n"}{"\n"}
She passed Mr. Skidder's door as he was red-inking a stage direc­
tion for Myrtle Delorme (Miss Leeson) in his (unaccepted)
comedy, to 'pirouette across stage from L to the side of the
Count.' Up the carpeted ladder she crawled at last and opened
the door of the skylight room.{"\n"}{"\n"}
She was too weak to light the lamp or to undress. She fell upon
the iron cot, her fragile body scarcely hollowing the worn springs.{"\n"}{"\n"}
And in that Erebus of a room she slowly raised her heavy eyelids,
and smiled.{"\n"}{"\n"}
For Billy Jackson was shining down on her, calm and bright and
constant through the skylight. There was no world about her. She
was sunk in a pit of blackness, with but that small square of pallid
light framing the star that she had so whimsically, and oh, so inef­
fectually, named. Miss Longnecker must be right; it was Gamma,
of the constellation Cassiopeia, and not Billy Jackson. And yet she
could not let it be Gamma.{"\n"}{"\n"}
As she lay on her back she tried twice to raise her arm. The
third time she got two thin fingers to her lips and blew a kiss out
of the black pit to Billy Jackson. Her arm fell back limply.{"\n"}{"\n"}
'Good-bye, Billy,' she murmured faintly. 'You're millions of
miles away and you won't even twinkle once. But you kept where I
could see you most of the time up there when there wasn't any­
thing else but darkness to look at, didn't you? . . . Millions of
m i l e s . . . . Good-bye, Billy Jackson.'{"\n"}
Clara, the coloured maid, found the door locked at ten the next
day, and they forced it open. Vinegar, and the slapping of wrists
and even burnt feathers, proving of no avail, someone ran to
'phone for an ambulance.{"\n"}{"\n"}
In due time it backed up to the door with much gong-clanging,
and the capable young medico, in his white linen coat, ready,
active, confident, with his smooth face half debonair, half grim,
danced up the steps.{"\n"}{"\n"}
'Ambulance call to 49,' he said briefly. 'What's the trouble?'
'Oh yes, doctor,' sniffed Mrs. Parker, as though her trouble that
there should be trouble in the house was the greater. 'I can't think
what can be the matter with her. Nothing we could do would
bring her to. It's a young woman, a Miss Elsie - yes, a Miss Elsie
Leeson. Never before in my house - '
'What room?' cried the doctor in a terrible voice, to which Mrs.{"\n"}{"\n"}
Parker was a stranger.{"\n"}{"\n"}
'The skylight room. It - '
Evidently the ambulance doctor was familiar with the location
of skylight rooms. He was gone up the stairs, four at a time. Mrs.{"\n"}{"\n"}
Parker followed slowly, as her dignity demanded.{"\n"}{"\n"}
On the first landing she met him coming back bearing the
astronomer in his arms. He stopped and let loose the practised
scalpel of his tongue, not loudly. Gradually Mrs. Parker crumpled
as a stiff garment that slips down from a nail. Ever afterwards
there remained crumples in her mind and body. Sometimes her
curious roomers would ask her what the doctor said to her.{"\n"}{"\n"}
'Let that be,' she would answer. 'If I can get forgiveness for
having heard it I will be satisfied.'{"\n"}
The ambulance physician strode with his burden through the
pack of hounds that follow the curiosity chase, and even they fell
back along the sidewalk abashed, for his face was that of one who
bears his own dead.{"\n"}{"\n"}
They noticed that he did not lay down upon the bed prepared
for it in the ambulance the form that he carried, and all that he
said was: 'Drive like h - l, Wilson,' to the driver.{"\n"}{"\n"}
That is all. Is it a story? In the next morning's paper I saw a
little news item, and the last sentence of it may help you (as it
helped me) to weld the incidents together.{"\n"}{"\n"}
It recounted the reception into Bellevue Hospital of a young
woman who had been removed from No. 49 East - Street, suffer­
ing from debility induced by starvation. It concluded with these
words:
'Dr. William Jackson, the ambulance physician who attended
the case, says the patient will recover.'{"\n"}


        </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}

