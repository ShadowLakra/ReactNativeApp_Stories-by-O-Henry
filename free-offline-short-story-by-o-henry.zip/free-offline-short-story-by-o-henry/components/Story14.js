import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import styles from './styles'
import { LinearGradient } from 'expo';
import Ad from './Ad'

export default class Story14 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
        <LinearGradient colors={styles.linearGradient.colors} >
       
        <Text style={styles.storyTitle}>
          A Municipal Report
       </Text>
        <Text style={styles.paragraph}>

The cities are full of pride,
Challenging each to each This from her mountainside,
That from her burthened beach.{"\n"}{"\n"}
R. KIPLING.{"\n"}{"\n"}

Fancy a novel about Chicago or Buffalo, let us say, or Nashville, Tennessee!
There are just three big cities in the United States that are 'story cities' - New
York, of course, New Orleans, and, best of the lot, San Francisco. - FRANK
NORRIS.{"\n"}{"\n"}

EAST IS EAST, and West is San Francisco, according to Californi­

ans. Californians are a race of people; they are not merely inhabi­
tants of a State. They are the Southerners of the West. Now,
Chicagoans are no less loyal to their city; but when you ask them
why, they stammer and speak of lake fish and the new Odd Fellows
Building. But Californians go into detail.{"\n"}{"\n"}

Of course they have, in the climate, an argument that is good
for half an hour while you are thinking of your coal bills and heavy
underwear. But as soon as they come to mistake your silence for
conviction, madness comes upon them, and they picture the city
of the Golden Gate as the Bagdad of the New World. So far, as a
matter of opinion, no refutation is necessary. But, dear cousins all
(from Adam and Eve descended), it is a rash one who will lay his
finger on the map and say: 'In this town there can be no romance
- what could happen here?' Yes, it is a bold and a rash deed to
challenge in one sentence history, romance, and Rand and
McNally.{"\n"}{"\n"}
NASHVILLE. - A city, port of delivery, and the capital of the State of Ten­
nessee, is on the Cumberland River and on the N.C. & St. L. and the L. & N.{"\n"}{"\n"}
railroads. This city is regarded as the most important educational centre in the
South.{"\n"}{"\n"}

I stepped off the train at 8 p.m. Having searched the thesaurus in
vain for adjectives, I must, as a substitution, hie me to comparison
in the form of a recipe.{"\n"}{"\n"}
Take of London fog 30 parts; malaria 10 parts; gas leaks 20
parts; dewdrops, gathered in a brickyard at sunrise, 25 parts; odour
of honeysuckle 15 parts. Mix.{"\n"}{"\n"}
The mixture will give you an approximate conception of a
Nashville drizzle. It is not so fragrant as a moth-ball nor as thick
as pea-soup; but 'tis enough - 'twill serve.{"\n"}{"\n"}
I went to an hotel in a tumbril. It required strong self-suppres­
sion for me to keep from climbing to the top of it and giving an
imitation of Sidney Carton. The vehicle was drawn by beasts of a
bygone era and driven by something dark and emancipated.{"\n"}{"\n"}
I was sleepy and tired, so when I got to the hotel I hurriedly
paid it the fifty cents it demanded (with approximate lagniappe, I
assure you). I knew its habits; and I did not want to hear it prate
about its old 'marster' or anything that happened 'befo' de wah.'{"\n"}
The hotel was one of the kind described as 'renovated.' That
means $20,000 worth of new marble pillars, tiling, electric lights
and brass cuspidors in the lobby, and a new L. & N. time table
and a lithograph of Lookout Mountain in each one of the great
rooms above. The management was without reproach, the atten­
tion full of exquisite Southern courtesy, the service as slow as the
progress of a snail and as good-humoured as Rip Van Winkle.{"\n"}{"\n"}
The food was worth travelling a thousand miles for. There is no
other hotel in the world where you can get such chicken livers en
brochette.{"\n"}{"\n"}
At dinner I asked a negro waiter if there was anything doing in
town. He pondered gravely for a minute, and then replied:
'Well, boss, I don't really reckon there's anything at all doin'
after sundown.'{"\n"}
Sundown had been accomplished; it had been drowned in the
drizzle long before. So that spectacle was denied me. But I went
forth upon the streets in the drizzle to see what might be there.{"\n"}{"\n"}
It is built on undulating grounds; and the streets are lighted by electricity at
a cost of $32,470 per annum.{"\n"}{"\n"}
As I left the hotel there was a race riot. Down upon me charged
a company of freedmen, or Arabs, or Zulus, armed with - no, I
saw with relief that they were not rifles, but whips. And I saw
dimly a caravan of black, clumsy vehicles; and at the reassuring
shouts, 'Kyar you anywhere in the town, boss, fuh fifty cents,' I
reasoned that I was merely a 'fare' instead of a victim.{"\n"}{"\n"}
I walked through long streets, all leading uphill. I wondered how
those streets ever came down again. Perhaps they didn't until they
were 'graded.' On a few of the 'main streets' I saw lights in stores
here and there; saw street-cars go by conveying worthy burghers
hither and yon; saw people pass engaged in the art of conversation,
and heard a burst of semi-lively laughter issuing from a soda-water
and ice-cream parlour. The streets other than 'main' seemed to
have enticed upon their borders houses consecrated to peace and
domesticity. In many of them lights shone behind discreetly drawn
window shades; in a few pianos tinkled orderly and irreproachable
music. There was, indeed, little 'doing.' I wished I had come before
sundown. So I returned to my hotel.{"\n"}{"\n"}
In November, 1864, the Confederate General Hood advanced against
Nashville, where he shut up a National force under General Thomas. The
latter then sallied forth and defeated the confederates in a terrible conflict.{"\n"}{"\n"}
All my life I have heard of, admired, and witnessed the fine
markmanship of the South in its peaceful conflicts in the tobaccochewing regions. But in my hotel a surprise awaited me. There
were twelve bright, new, imposing, capacious brass cuspidors in
the great lobby, tall enough to be called urns and so widemouthed that the crack pitcher of a lady baseball team should
have been able to throw a ball into one of them at five paces dis­
tant. But, although a terrible battle had raged and was still raging,
the enemy had not suffered. Bright, new, imposing, capacious,
untouched, they stood. But shades of Jefferson Brick! the tile
floor - the beautiful tile floor! I could not avoid thinking of the
battle of Nashville, and trying to draw, as is my foolish habit,
some deductions about hereditary markmanship.{"\n"}{"\n"}
Here I first saw Major (by misplaced courtesy) Wentworth
Caswell. I knew him for a type the moment my eyes suffered from
the sight of him. A rat has no geographical habitat. M y old friend,
A. Tennyson, said, as he so well said almost everything:
'Prophet, curse me the blabbing lip,
And curse me the British vermin, the rat.'{"\n"}

Let us regard the word 'British' as interchangeable ad lib. A rat
is a rat.{"\n"}{"\n"}
This man was hunting about the hotel lobby like a starved dog
that had forgotten where he had buried a bone. He had a face of
great acreage, red, pulpy, and with a kind of sleepy massiveness
like that of Buddha. He possessed one single virtue - he was very
smoothly shaven. The mark of the beast is not indelible upon a
man until he goes about with a stubble. I think that if he had not
used his razor that day I would have repulsed his advances, and the
criminal calendar of the world would have been spared the addi­
tion of one murder.{"\n"}{"\n"}
I happened to be standing within five feet of a cuspidor when
Major Caswell opened fire upon it. I had been observant enough
to perceive that the attacking force was using Gatlings instead of
squirrel rifles; so I side-stepped so promptly that the major seized
the opportunity to apologize to a non-combatant. He had the
blabbing lip. In four minutes he had become my friend and had
dragged me to the bar.{"\n"}{"\n"}
I desire to interpolate here that I am a Southerner. But I am not
one by profession or trade. I eschew the string tie, the slouch hat,
the Prince Albert, the number of bales of cotton destroyed by
Sherman, and plug chewing. When the orchestra plays Dixie I do
not cheer. I slide a little lower on the leather-cornered seat and,
well, order another Würzburger and wish that Longstreet had but what's the use?
Major Caswell banged the bar with his fist, and the first gun at
Fort Sumter re-echoed. When he fired the last one at Appomattox
I began to hope. But then he began on family trees, and demon­
strated that Adam was only a third cousin of a collateral branch of
the Caswell family. Genealogy disposed of, he took up, to my dis­
taste, his private family matters. He spoke of his wife, traced her
descent back to Eve, and profanely denied any possible rumour
that she may have had relations in the land of Nod.{"\n"}{"\n"}
By this time I began to suspect that he was trying to obscure by
noise the fact that he had ordered the drinks, on the chance that I
would be bewildered into paying for them. But when they were
down he crashed a silver dollar loudly upon the bar. Then, of
course, another serving was obligatory. And when I had paid for
that I took leave of him brusquely; for I wanted no more of him.{"\n"}{"\n"}
But before I had obtained my release he had prated loudly of an
income that his wife received, and showed a handful of silver
money.{"\n"}{"\n"}
When I got my key at the desk the clerk said to me courteously:
'If that man Caswell has annoyed you, and if you would like to
make a complaint, we will have him ejected. He is a nuisance, a
loafer, and without any known means of support, although he
seems to have some money most the time. But we don't seem to
be able to hit upon any means of throwing him out legally.'{"\n"}
'Why, no,' said I, after some reflection; 'I don't see my way
clear to making a complaint. But I would like to place myself on
record as asserting that I do not care for his company. Your town,'
I continued, 'seems to be a quiet one. What manner of entertain­
ment, adventure, or excitement have you to offer to the stranger
within your gates?'
'Well, sir,' said the clerk, 'there will be a show here next Thurs­
day. It is - I'll look it up and have the announcement sent up to
your room with the ice water. Good night.'{"\n"}
After I went up to my room I looked out of the window. It was
only about ten o'clock, but I looked upon a silent town. The driz­
zle continued, spangled with dim lights, as far apart as currants in
a cake sold at the Ladies' Exchange.{"\n"}{"\n"}
'A quiet place,' I said to myself, as my first shoe struck the ceil­
ing of the occupant of the room beneath mine. 'Nothing of the
life here that gives colour and variety to the cities in the East and
West. Just a good, ordinary, humdrum business town.'{"\n"}
Nashville occupies aforemostplace among the manufacturing centres of the
country. It is the fifth boot and shoe market in the United States, the largest
candy and cracker manufacturing city in the South, and does an enormous
wholesale dry goods, grocery and drug business.{"\n"}{"\n"}
I must tell you how I came to be in Nashville, and assure you
the digression brings as much tedium to me as it does to you. I
was travelling elsewhere on my own business, but I had a commission from a Northern literary magazine to stop over there and
establish a personal connection between the publication and one
of its contributors, Azalea Adair.{"\n"}{"\n"}
Adair (there was no clue to the personality except the handwriting) had sent in some essays (lost art!) and poems that had made
the editors swear approvingly over their one o'clock luncheon. So
they had commissioned me to round up said Adair and corner by
contract his or her output at two cents a word before some other
publisher offered her ten or twenty.{"\n"}{"\n"}
At nine o'clock the next morning, after my chicken livers en brochette (try them if you can find that hotel), I strayed out into the
drizzle, which was still on for an unlimited run. At the first corner
I came upon Uncle Cæsar. He was a stalwart negro, older than the
pyramids, with grey wool and a face that reminded me of Brutus,
and a second afterwards of the late King Cetewayo. He wore the
most remarkable coat that I ever had seen or expect to see. It
reached to his ankles and had once been a Confederate grey in
colours. But rain and sun and age had so variegated it that Joseph's
coat, beside it, would have faded to a pale monochrome. I must
linger with that coat for it has to do with the story - the story that
is so long in coming, because you can hardly expect anything to
happen in Nashville.{"\n"}{"\n"}
Once it must have been the military coat of an officer. The cape
of it had vanished, but all adown its front it had been frogged and
tasselled magnificently. But now the frogs and tassels were gone.{"\n"}{"\n"}
In their stead had been patiently stitched (I surmised by some surviving 'black mammy') new frogs made of cunningly twisted
common hempen twine. This twine was frayed and dishevelled. It
must have been added to the coat as a substitute for vanished
splendours, with tasteless but painstaking devotion, for it followed
faithfully the curves of the long-missing frogs. And, to complete
the comedy and pathos of the garment, all its buttons were gone
save one. The second button from the top alone remained. The
coat was fastened by other twine strings tied through the buttonholes and other holes rudely pierced in the opposite side. There
was never such a weird garment so fantastically bedecked and of so
many mottled hues. The lone button was the size of a half-dollar,
made of yellow horn and sewed on with coarse twine.{"\n"}{"\n"}
This negro stood by a carriage so old that Ham himself might
have started a hack line with it after he left the ark with the two
animals hitched to it. As I approached he threw open the door,
drew out a leather duster, waved it, without using it, and said in
deep, rumbling tones:
'Step right in, suh; ain't a speck of dust in it - jus' back from a
funeral, suh.'{"\n"}
I inferred that on such gala occasions carriages were given an
extra cleaning. I looked up and down the street and perceived that
there was little choice among the vehicles for hire that lined the
kerb. I looked in my memorandum book for the address of Azalea
Adair.{"\n"}{"\n"}
'I want to go to 861 Jessamine Street,' I said, and was about to
step into the hack. But for an instant the thick, long, gorilla-like
arm of the old negro barred me. On his massive and saturnine face
a look of sudden suspicion and enmity flashed for a moment.{"\n"}{"\n"}
Then, with quickly returning conviction, he asked blandishingly:
'What are you gwine there for, boss?'
'What is that to you?' I asked a little sharply.{"\n"}{"\n"}
'Nothin', suh, jus' nothin'. Only it's a lonesome kind of part of
town and few folks ever has business out there. Step right in. The
seats is clean - jes' got back from a funeral, suh.'{"\n"}
A mile and a half it must have been to our journey's end. I could
hear nothing but the fearful rattle of the ancient hack over the
uneven brick paving; I could smell nothing but the drizzle, now
further flavoured with coal smoke and something like a mixture of
tar and oleander blossoms. All I could see through the streaming
windows were two rows of dim houses.{"\n"}{"\n"}
The city has an area of 10 square miles; 181 miles of streets, of which 137
miles are paved; a system of waterworks that cost $2,000,000, with 77 miles of
mains.{"\n"}{"\n"}

Eight-sixty-one Jessamine Street was a decayed mansion. Thirty
yards back from the street it stood, outmerged in a splendid grove
of trees and untrimmed shrubbery. A row of box bushes over­
flowed and almost hid the paling fence from sight; the gate was
kept closed by a rope noose that encircled the gate-post and the
first paling of the gate. But when you got inside you saw that 861
was a shell, a shadow, a ghost of former grandeur and excellence.{"\n"}{"\n"}
But in the story, I have not yet got inside.{"\n"}{"\n"}
When the hack had ceased from rattling and the weary
quadrupeds came to a rest I handed my jehu his fifty cents with an
additional quarter, feeling a glow of conscious generosity as I did
so. He refused it.{"\n"}{"\n"}
'It's two dollars, suh,' he said.{"\n"}{"\n"}
'How's that?' I asked. 'I plainly heard you call out at the hotel:
"Fifty cents to any part of the town." '
'It's two dollars, suh,' he repeated obstinately. 'It's a long ways
from the hotel.'{"\n"}
'It is within the city limits and well within them,' I argued.{"\n"}{"\n"}
'Don't think that you have picked up a greenhorn Yankee. Do you
see those hills over there?' I went on, pointing toward the east (I
could not see them, myself, for the drizzle); 'well, I was born and
raised on their other side. You old fool nigger, can't you tell
people from other people when you see em?'
The grim face of King Cetewayo softened. 'Is you from the
South, suh? I reckon it was them shoes of yourn fooled me. There
is somethin' sharp in the toes for a Southern gen'l'man to wear.'{"\n"}
'Then the charge is fifty cents, I suppose?' said I inexorably.{"\n"}{"\n"}
His former expression, a mingling of cupidity and hostility,
returned, remained ten minutes, and vanished.{"\n"}{"\n"}
'Boss,' he said, 'fifty cents is right; but I needs two dollars, suh;
I'm obleeged to have two dollars. I ain't demandin' it now, suh;
after I knows whar you's from; I'm jus' sayin' that I has to have
two dollars to-night, and business is mighty po'.'{"\n"}
Peace and confidence settled upon his heavy features. He had
been luckier than he had hoped. Instead of having picked up a
greenhorn, ignorant of rates, he had come upon an inheritance.{"\n"}{"\n"}
'You confounded old rascal,' I said, reaching down into my
pocket, 'you ought to be turned over to the police.'{"\n"}
For the first time I saw him smile. He knew; he knew; HE KNEW.{"\n"}{"\n"}
I gave him two one-dollar bills. As I handed them over I noticed
that one of them had seen parlous times. Its upper right-hand
corner was missing, and it had been torn through in the middle
but joined again. A strip of blue tissue-paper, pasted over the split,
preserved its negotiability.{"\n"}{"\n"}
Enough of the African bandit for the present: I left him happy,
lifted the rope and opened the creaky gate.{"\n"}{"\n"}
The house, as I said, was a shell. A paint-brush had not touched
it in twenty years. I could not see why a strong wind should not
have bowled it over like a house of cards until I looked again at the
trees that hugged it close - the trees that saw the battle of
Nashville and still drew their protecting branches around it
against storm and enemy and cold.{"\n"}{"\n"}
Azalea Adair, fifty years old, white-haired, a descendant of the
cavaliers, as thin and frail as the house she lived in, robed in the
cheapest and cleanest dress I ever saw, with an air as simple as a
queen's, received me.{"\n"}{"\n"}
The reception-room seemed a mile square, because there was
nothing in it except some rows of books, on unpainted, white-pine
bookshelves, a cracked, marble-top table, a rag rug, a hairless horse­
hair sofa and two or three chairs. Yes, there was a picture on the wall,
a coloured crayon drawing of a cluster of pansies. I looked around
for the portrait of Andrew Jackson and the pine-cone hanging
basket, but they were not there.{"\n"}{"\n"}
Azalea Adair and I had conversation, a little of which will be
repeated to you. She was a product of the old South, gently nur­
tured in the sheltered life. Her learning was not broad, but was
deep and of splendid originality in its somewhat narrow scope. She
had been educated at home, and her knowledge of the world was
derived from inference and by inspiration. Of such is the precious,
small group of essayists made. While she talked to me, I kept
brushing my fingers, trying, unconsciously, to rid them guiltily of
the absent dust from the half-calf backs of Lamb, Chaucer,
Hazlitt, Marcus Aurelius, Montaigne and Hood. She was exquis­
ite, she was a valuable discovery. Nearly everybody nowadays
knows too much - oh, so much too much - of real life.{"\n"}{"\n"}
I could perceive clearly that Azalea Adair was very poor. A
house and a dress she had, not much else, I fancied. So, divided
between my duty to the magazine and my loyalty to the poets and
essayists who fought Thomas in the valley of the Cumberland, I
listened to her voice, which was like a harpsichord's, and found
that I could not speak of contracts. In the presence of the Nine
Muses and the Three Graces one hesitated to lower the topic to
two cents. There would have to be another colloquy after I had
regained my commercialism. But I spoke of my mission, and
three o'clock of the next afternoon was set for the discussion of
the business proposition.{"\n"}{"\n"}
'Your town,' I said, as I began to make ready to depart (which is
the time for smooth generalities), 'seems to be a quiet, sedate
place. A home town, I should say, where few things out of the
ordinary ever happen.'{"\n"}
It carries on an extensive trade in stoves and hollow ware with the West and
South, and its flouring mills have a daily capacity of more than 2,000 barrels.{"\n"}{"\n"}
Azalea Adair seemed to reflect.{"\n"}{"\n"}
'I have never thought of it that way,' she said, with a kind of sin­
cere intensity that seemed to belong to her. 'Isn't it in the still,
quiet places that things do happen? I fancy that when God began
to create the earth on the first Monday morning one could have
leaned out one's windows and heard the drop of mud splashing
from His trowel as He built up the everlasting hills. What did the
noisiest project in the world - I mean the building of the tower of
Babel - result in finally? A page and a half of Esperanto in the
North American Review.'{"\n"}
'Of course,' said I platitudinously, 'human nature is the same
everywhere; but there is more colour - er - more drama and
movement and - er - romance in some cities than in others.'{"\n"}
'On the surface,' said Azalea Adair. 'I have travelled many
times around the world in a golden airship wafted on two wings
- print and dreams. I have seen (on one of my imaginary tours)
the Sultan of Turkey bow-string with his own hands one of his
wives who had uncovered her face in public. I have seen a man in
Nashville tear up his theatre tickets because his wife was going
out with her face covered - with rice powder. In San Francisco's
Chinatown I saw the slave girl Sing Yee dipped slowly, inch by
inch, in boiling almond oil to make her swear she would never
see her American lover again. She gave in when the boiling oil
had reached three inches above her knee. At a euchre party in
East Nashville the other night I saw Kitty Morgan cut dead by
seven of her schoolmates and lifelong friends because she had
married a house painter. The boiling oil was sizzling as high as
her heart; but I wish you could have seen the fine little smile that
she carried from table to table. Oh yes, it is a humdrum town.{"\n"}{"\n"}
Just a few miles of redbrick houses and mud and stores and
lumber yards.'{"\n"}
Someone knocked hollowly at the back of the house. Azalea
Adair breathed a soft apology and went to investigate the sound.{"\n"}{"\n"}
She came back in three minutes with brightened eyes, a faint flush
on her cheeks, and ten years lifted from her shoulders.{"\n"}{"\n"}
'You must have a cup of tea before you go,' she said, 'and a
sugar cake.'{"\n"}
She reached and shook a little iron bell. In shuffled a small
negro girl about twelve, bare-foot, not very tidy, glowering at me
with thumb in mouth and bulging eyes.{"\n"}{"\n"}
Azalea Adair opened a tiny, worn purse and drew out a dollar
bill, a dollar bill with the upper right-hand corner missing, torn in
two pieces and pasted together again with a strip of blue tissuepaper. It was one of the bills I had given the piratical negro - there
was no doubt of it.{"\n"}{"\n"}
'Go up to Mr. Baker's store on the corner, Impy,' she said,
handing the girl the dollar bill, 'and get a quarter of a pound of tea
- the kind he always sends me - and ten cents worth of sugar
cakes. Now, hurry. The supply of tea in the house happens to be
exhausted,' she explained to me.{"\n"}{"\n"}
Impy left by the back way. Before the scrape of her hard, bare
feet had died away on the back porch, a wild shriek - I was sure it
was hers - filled the hollow house. Then the deep, gruff tones of
an angry man's voice mingled with the girl's further squeals and
unintelligible words.{"\n"}{"\n"}
Azalea Adair rose without surprise or emotion and disappeared.{"\n"}{"\n"}
For two minutes I heard the hoarse rumble of the man's voice;
then something like an oath and a light scuffle, and she returned
calmly to her chair.{"\n"}{"\n"}
'This is a roomy house,' she said, 'and I have a tenant for part of
it. I am sorry to have to rescind my invitation to tea. It was impos­
sible to get the kind I always use at the store. Perhaps to-morrow
Mr. Baker will be able to supply me.'{"\n"}
I was sure that Impy had not had time to leave the house. I
inquired concerning street-car lines and took my leave. After I was
well on my way I remembered that I had not learned Azalea
Adair's name. But to-morrow would do.{"\n"}{"\n"}
That same day I started in on the course of iniquity that this
uneventful city forced upon me. I was in the town only two days,
but in that time I managed to lie shamelessly by telegraph, and to
be an accomplice - after the fact, if that is the correct legal term to a murder.{"\n"}{"\n"}
As I rounded the corner nearest my hotel the Afrite coachman
of the polychromatic, nonpareil coat seized me, swung open the
dungeony door of his peripatetic sarcophagus, flirted his feather
duster and began his ritual: 'Step right in, boss. Carriage is clean jus' got back from a funeral. Fifty cents to any- '
And then he knew me and grinned broadly. ' 'Scuse me, boss;
you is de gen'l'man what rid out with me dis mawnin'. Thank you
kindly, suh.'{"\n"}
'I am going out to 861 again to-morrow afternoon at three,' said
I, 'and if you will be here, I'll let you drive me. So you know Miss
Adair?' I concluded, thinking of my dollar bill.{"\n"}{"\n"}
'I belonged to her father, Judge Adair, suh,' he replied.{"\n"}{"\n"}
'I judge that she is pretty poor,' I said. 'She hasn't much money
to speak of, has she?'
For an instant I looked again at the fierce countenance of King
Cetewayo, and then he changed back to an extortionate old negro
hack-driver.{"\n"}{"\n"}
'She a'n't gwine to starve, suh,' he said slowly. 'She has reso'ces,
suh; she has reso'ces.'{"\n"}
'I shall pay you fifty cents for the trip,' said I.{"\n"}{"\n"}
'Dat is puffeckly correct, suh,' he answered humbly; 'I jus' had
to have dat two dollars dis mawnin, boss.'{"\n"}
I went to the hotel and lied by electricity. I wired the magazine:
'A. Adair holds out for eight cents a word.'{"\n"}
The answer that came back was: 'Give it to her quick, you
duffer.'{"\n"}
Just before dinner 'Major' Wentworth Caswell bore down upon
me with the greetings of a long-lost friend. I have seen few men
whom I have so instantaneously hated, and of whom it was so dif­
ficult to be rid. I was standing at the bar when he invaded me;
therefore I could not wave the white ribbon in his face. I would
have paid gladly for the drinks, hoping thereby to escape another,
but he was one of those despicable, roaring, advertising bibbers
who must have brass bands and fireworks attend upon every cent
that they waste in their follies.{"\n"}{"\n"}
With an air of producing millions he drew two one-dollar bills
from a pocket and dashed one of them upon the bar. I looked once
more at the dollar bill with the upper right-hand corner missing, torn
through the middle, and patched with a strip of blue tissue-paper. It
was my dollar bill again. It could have been no other.{"\n"}{"\n"}
I went up to my room. The drizzle and the monotony of a
dreary, eventless Southern town had made me tired and listless. I
remember that just before I went to bed I mentally disposed of the
mysterious dollar bill (which might have formed the clue to a
tremendously fine detective story of San Francisco) by saying to
myself sleepily: 'Seems as if a lot of people here own stock in the
Hack-Driver's Trust. Pays dividends promptly, too. Wonder if- '
Then I fell asleep.{"\n"}{"\n"}
King Cetewayo was at his post the next day, and rattled my
bones over the stones out to 861. He was to wait and rattle me
back again when I was ready.{"\n"}{"\n"}
Azalea Adair looked paler and cleaner and frailer than she had
looked on the day before. After she had signed the contract at eight
cents per word she grew still paler and began to slip out of her chair.{"\n"}{"\n"}
Without much trouble I managed to get her up on the antediluvian
horsehair sofa and then I ran out to the sidewalk and yelled to the
coffee-coloured Pirate to bring a doctor. With a wisdom that I had
not suspected in him, he abandoned his team and struck off up the
street afoot, realizing the value of speed. In ten minutes he returned
with a grave, grey-haired and capable man of medicine. In a few
words (worth much less than eight cents each) I explained to him
my presence in the hollow house of mystery. He bowed with stately
understanding, and turned to the old negro.{"\n"}{"\n"}
'Uncle Cæsar,' he said calmly, 'run up to my house and ask Miss
Lucy to give you a cream pitcher full of fresh milk and half a tumbler of port wine. And hurry back. Don't drive - run. I want you
to get back some time this week.'{"\n"}
It occurred to me that Dr. Merriman also felt a distrust as to the
speeding powers of the landpirate's steeds. After Uncle Cæsar was
gone, lumberingly, but swiftly, up the street, the doctor looked me
over with great politeness and as much careful calculation until he
had decided that I might do.{"\n"}{"\n"}
'It is only a case of insufficient nutrition,' he said. 'In other
words, the result of poverty, pride, and starvation. Mrs. Caswell
has many devoted friends who would be glad to aid her, but she
will accept nothing except from that old negro, Uncle Cæsar, who
was once owned by her family.'{"\n"}
'Mrs. Caswell!' said I, in surprise. And then I looked at the
contract and saw that she had signed it 'Azalea Adair Caswell.'{"\n"}
'I thought she was Miss Adair,' I said.{"\n"}{"\n"}
'Married to a drunken, worthless loafer, sir,' said the doctor. 'It
is said that he robs her even of the small sums that her old servant
contributes toward her support.'{"\n"}
When the milk and wine had been brought, the doctor soon
revived Azalea Adair. She sat up and talked of the beauty of the
autumn leaves that were then in season, and their height of colour.{"\n"}{"\n"}
She referred lightly to her fainting seizure as the outcome of an
old palpitation of the heart. Impy fanned her as she lay on the
sofa. The doctor was due elsewhere, and I followed him to the
door. I told him that it was within my power and intentions to
make a reasonable advance of money to Azalea Adair on future
contributions to the magazine, and he seemed pleased.{"\n"}{"\n"}
'By the way,' he said, 'perhaps you would like to know that you
have had royalty for a coachman. Old Cæsar's grandfather was a
king in Congo. Cæsar himself has royal ways, as you may have
observed.'{"\n"}
As the doctor was moving off I heard Uncle Cæsar's voice
inside: 'Did he git bofe of dem two dollars from you, Mis' Zalea?'
'Yes, Cæsar,' I heard Azalea Adair answer weakly. And then I
went in and concluded business negotiations with our contributor.{"\n"}{"\n"}
I assumed the responsibility of advancing fifty dollars, putting it as
a necessary formality in binding our bargain. And then Uncle
Cæsar drove me back to the hotel.{"\n"}{"\n"}
Here ends all the story as far as I can testify as a witness. The
rest must be only bare statements of facts.{"\n"}{"\n"}
At about six o'clock I went out for a stroll. Uncle Cæsar was at
his corner. He threw open the door of his carriage, flourished his
duster and began his depressing formula: 'Step right in, suh. Fifty
cents to anywhere in the city - hack's puffickly clean, suh - jus' got
back from a funeral- '
And then he recognized me. I think his eyesight was getting
bad. His coat had taken on a few more faded shades of colour, the
twine strings were more frayed and ragged, the last remaining
button - the button of yellow horn - was gone. A motley descendant of kings was Uncle Caesar.{"\n"}{"\n"}
About two hours later I saw an excited crowd besieging the
front of a drug store. In a desert where nothing happens this was
manna; so I edged my way inside. On an extemporized couch of
empty boxes and chairs was stretched the mortal corporeality of
Major Wentworth Caswell. A doctor was testing him for the
immortal ingredient. His decision was that it was conspicuous by
its absence.{"\n"}{"\n"}
The erstwhile Major had been found dead on a dark street and
brought by curious and ennuied citizens to the drug store. The
late human being had been engaged in terrific battle - the details
showed that. Loafer and reprobate though he had been, he had
been also a warrior. But he had lost. His hands were yet clenched
so tightly that his fingers would not be opened. The gentle citizens who had known him stood about and searched their vocabularies to find some good words, if it were possible, to speak of him.{"\n"}{"\n"}
One kind-looking man said, after much thought: 'When "Cas"
was about fo'teen he was one of the best spellers in school.'{"\n"}
While I stood there the fingers of the right hand of 'the man
that was,' which hung down the side of a white pine box, relaxed,
and dropped something at my feet. I covered it with one foot quietly, and a little later on I picked it up and pocketed it. I reasoned
that in his last struggle his hand must have seized that object
unwittingly and held it in a death-grip.{"\n"}{"\n"}

At the hotel that night the main topic of conversation, with the
possible exceptions of politics and prohibition, was the demise of
Major Caswell. I heard one man say to a group of listeners:
'In my opinion, gentlemen, Caswell was murdered by some of
these no-account niggers for his money. He had fifty dollars this
afternoon which he showed to several gentlemen in the hotel.{"\n"}{"\n"}
When he was found the money was not on his person.'{"\n"}
I left the city the next morning at nine, and as the train was
crossing the bridge over the Cumberland River I took out of my
pocket a yellow, horn, overcoat button the size of a fifty-cent
piece, with frayed ends of coarse twine hanging from it, and cast it
out of the window into the slow, muddy waters below.{"\n"}{"\n"}
I wonder what's doing in Buffalo! ' {"\n"}{"\n"}
       </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}


