import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import styles from './styles'
import { LinearGradient } from 'expo';
import Ad from './Ad'

export default class Story3 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
        <LinearGradient colors={styles.linearGradient.colors} >
        <Text style={styles.storyTitle}>
          Between Rounds
       </Text>
        <Text style={styles.paragraph}>


THE MAY MOON SHONE BRIGHT upon the private boarding-house

of Mrs. Murphy. By reference to the almanac a large amount of
territory will be discovered upon which its rays also fell. Spring
was in its heyday, with hay fever soon to follow. The parks were
green with new leaves and buyers for the Western and Southern
trade. Flowers and summer-resort agents were blowing; the air
and answers to Lawson were growing milder; hand-organs, foun­
tains and pinochle were playing everywhere.{"\n"}{"\n"}
The windows of Mrs. Murphy's boarding-house were open. A
group of boarders were seated on the high stoop upon round, flat
mats like German pancakes.{"\n"}{"\n"}
In one of the second-floor front windows Mrs. McCaskey
awaited her husband. Supper was cooling on the table. Its heat
went into Mrs. McCaskey.{"\n"}{"\n"}
At nine Mr. McCaskey came. He carried his coat on his arm and
his pipe in his teeth; and he apologized for disturbing the boarders
on the steps as he selected spots of stone between them on which
to set his size 9, width Ds.{"\n"}{"\n"}
As he opened the door of his room he received a surprise.{"\n"}{"\n"}
Instead of the usual stove-lid or potato-masher for him to dodge,
came only words.{"\n"}{"\n"}
Mr. McCaskey reckoned that the benign May moon had soft­
ened the breast of his spouse.{"\n"}{"\n"}
'I heard ye,' came the oral substitutes for kitchenware. 'Ye can
apollygize to riff-raff of the streets for settin' yer unhandy feet on
the tails of their frocks, but ye'd walk on the neck of yer wife the
length of a clothes-line without so much as a "Kiss me fut," and
I'm sure, it's that long from rubberin' out the windy for ye and the
victuals cold such as there's money to buy after drinkin' up yer
wages at Gallegher's every Saturday evenin', and the gas man here
twice to-day for his.'{"\n"}
'Woman!' said Mr. McCaskey, dashing his coat and hat upon a
chair, 'the noise of ye is an insult to me appetite. When ye run
down politeness ye take the mortar from between the bricks of the
foundations of society. 'Tis no more than exercisin' the acrimony
of a gentleman when ye ask the dissent of ladies blockin' the way
for steppin' between them. Will ye bring the pig's face of ye out of
the windy and see to the food?'
Mrs. McCaskey arose heavily and went to the stove. There was
something in her manner that warned Mr. McCaskey. When the
corners of her mouth went down suddenly like a barometer it usually
foretold a fall of crockery and tinware.{"\n"}{"\n"}
'Pig's face, is it?' said Mrs. McCaskey, and hurled a stewpan full
of bacon and turnips at her lord.{"\n"}{"\n"}
Mr. McCaskey was no novice at repartee. He knew what should
follow the entree. On the table was a roast sirloin of pork, gar­
nished with shamrocks. He retorted with this, and drew the
appropriate return of a bread pudding in an earthen dish. A hunk
of Swiss cheese accurately thrown by her husband struck Mrs.{"\n"}{"\n"}
McCaskey below one eye. When she replied with a well-aimed
coffee-pot full of a hot, black, semi-fragrant liquid the battle,
according to courses, should have ended.{"\n"}{"\n"}
But Mr. McCaskey was no 50 cent table d'hôter. Let cheap
Bohemians consider coffee the end, if they would. Let them make
that faux pas. He was foxier still. Finger-bowls were not beyond
the compass of his experience. They were not to be had in the
Pension Murphy; but their equivalent was at hand. Triumphantly
he sent the granite-ware wash-basin at the head of his matrimo­
nial adversary. Mrs. McCaskey dodged in time. She reached for a
flat-iron, with which, as a sort of cordial, she hoped to bring the
gastronomical duel to a close. But a loud, wailing scream down­
stairs caused both her and Mr. McCaskey to pause in a sort of
involuntary armistice.{"\n"}{"\n"}
On the sidewalk at the corner of the house Policeman Cleary
was standing with one ear upturned, listening to the crash of
household utensils.{"\n"}{"\n"}
' ' T i s Jawn McCaskey and his missus at it again,' meditated the
policeman. 'I wonder shall I go up and stop the row. I will not.{"\n"}{"\n"}
Married folks they are; and few pleasures they have. 'Twill not last
long. Sure, they'll have to borrow more dishes to keep it up with.'{"\n"}
And just then came the loud scream below-stairs, betokening
fear or dire extremity. ' 'Tis probably the cat,' said Policeman
Cleary, and walked hastily in the other direction.{"\n"}{"\n"}
The boarders on the steps were fluttered. Mr. Toomey, an
insurance solicitor by birth and an investigator by profession,
went inside to analyse the scream. He returned with the news that
Mrs. Murphy's little boy Mike was lost. Following the messenger,
out bounced Mrs. Murphy - two hundred pounds in tears and
hysterics, clutching the air and howling to the sky for the loss of
thirty pounds of freckles and mischief. Bathos, truly; but Mr.{"\n"}{"\n"}
Toomey sat down at the side of Miss Purdy, milliner, and their
hands came together in sympathy. The two old maids, Misses
Walsh, who complained every day about the noise in the halls,
inquired immediately if anybody had looked behind the clock.{"\n"}{"\n"}
Major Grigg, who sat by his fat wife on the top step, arose and
buttoned his coat. 'The little one lost?' he exclaimed. 'I will scour
the city.' His wife never allowed him out after dark. But now she
said: 'Go, Ludovic!' in a baritone voice. 'Whoever can look upon
that mother's grief without springing to her relief has a heart of
stone.' 'Give me some thirty or - sixty cents, my love,' said the
Major. 'Lost children sometimes stray far. I may need car-fares.'{"\n"}
Old man Denny, hall-room, fourth floor back, who sat on the
lowest step, trying to read a paper by the street lamp, turned over
a page to follow up the article about the carpenters' strike. Mrs.{"\n"}{"\n"}
Murphy shrieked to the moon: 'Oh, ar-r-Mike, f'r Gawd's sake,
where is me little bit av a boy?'
'When'd ye see him last?' asked old man Denny, with one eye
on the report of the Building Trades League.{"\n"}{"\n"}
'Oh,' wailed Mrs. Murphy,.' 'twas yisterday, or maybe four
hours ago! I dunno. But it's lost he is, me little boy Mike. He was
playin' on the sidewalk only this mornin' - or was it Wednesday?
I'm that busy with work 'tis hard to keep up with dates. But I've
looked the house over from top to cellar, and it's gone he is. Oh,
for the love av Hiven - '
Silent, grim, colossal, the big city has ever stood against its
revilers. They call it hard as iron; they say that no pulse of pity
beats in its bosom; they compare its streets with lonely forests and
deserts of lava. But beneath the hard crust of the lobster is found a
delectable and luscious food. Perhaps a different simile would have
been wiser. Still, nobody should take offence. W e would call no
one a lobster without good and sufficient claws.{"\n"}{"\n"}
No calamity so touches the common heart of humanity as does
the straying of a little child. Their feet are so uncertain and feeble;
the ways are so steep and strange.{"\n"}{"\n"}
Major Griggs hurried down to the corner, and up the avenue
into Billy's place. 'Gimme a rye-high,' he said to the servitor.{"\n"}{"\n"}
'Haven't seen a bow-legged, dirty-faced little devil of a six-yearold lost kid around here anywhere, have you?'
Mr. Toomey retained Miss Purdy's hand on the steps. 'Think of
that dear little babe,' said Miss Purdy, 'lost from his mother's side
- perhaps already fallen beneath the iron hoofs of galloping steeds
- oh, isn't it dreadful?'
'Ain't that right?' agreed Mr. Toomey, squeezing her hand. 'Say
I start out and help look for um!'
'Perhaps,' said Miss Purdy, 'you should. But oh, Mr. Toomey,
you are so dashing - so reckless - suppose in your enthusiasm
some accident should befall you, then what - '
Old man Denny read on about the arbitration agreement, with
one finger on the lines.{"\n"}{"\n"}
In the second floor front Mr. and Mrs. McCaskey came to the
window to recover their second wind. Mr. McCaskey was scoop­
ing turnips out of his vest with a crooked forefinger, and his lady
was wiping an eye that the salt of the roast pork had not benefited.{"\n"}{"\n"}
They heard the outcry below, and thrust their heads out of the
window.{"\n"}{"\n"}
' 'Tis little Mike is lost,' said Mrs. McCaskey in a hushed voice,
'the beautiful, little, trouble-making angel of a gossoon!'
'The bit of a boy mislaid?' said Mr. McCaskey leaning out of
the window. 'Why, now, that's bad enough, entirely. The childer,
they be different. If 'twas a woman I'd be willin', for they leave
peace behind 'em when they go.'{"\n"}
Disregarding the thrust, Mrs. McCaskey caught her husband's
arm.{"\n"}{"\n"}
'Jawn,' she said sentimentally, 'Missis Murphy's little bye is lost.{"\n"}{"\n"}
'Tis a great city for losing little boys. Six years old he was. Jawn,
'tis the same age our little bye would have been if we had had one
six years ago.'{"\n"}
'We never did,' said Mr. McCaskey, lingering with the fact.{"\n"}{"\n"}
'But if we had, Jawn, think what sorrow would be in our hearts
this night, with our little Phelan run away and stolen in the city
nowheres at all.'{"\n"}
'Ye talk foolishness,' said Mr. McCaskey. ' 'Tis Pat he would be
named, after me old father in Cantrim.'{"\n"}
'Ye lie!' said Mrs. McCaskey, without anger. 'Me brother was
worth tin dozen bog-trotting McCaskeys. After him would the bye
be named.' She leaned over the window-sill and looked down at
the hurrying and bustle below.{"\n"}{"\n"}
'Jawn,' said Mrs. McCaskey softly, 'I'm sorry I was hasty wid
ye.'{"\n"}
' 'Twas hasty puddin', as ye say,' said her husband, 'and hurryup turnips and get-a-move-on-ye coffee. 'Twas what ye could call
a quick lunch, all right, and tell no lie.'{"\n"}
Mrs. McCaskey slipped her arm inside her husband's and took
his rough hand in hers.{"\n"}{"\n"}
'Listen at the cryin' of poor Mrs. Murphy,' she said. ' 'Tis an
awful thing for a bit of a bye to be lost in this great big city. If
'twas our little Phelan, Jawn, I'd be breakin' me heart.'{"\n"}
Awkwardly Mr. McCaskey withdrew his hand. But he laid it
around the nearing shoulders of his wife.{"\n"}{"\n"}
' 'Tis foolishness, of course,' said he, roughly, 'but I'd be cut up
some meself, if our little - Pat was kidnapped or anything. But
there never was any childer for us. Sometimes I've been ugly and
hard with ye, Judy. Forget it.'{"\n"}
They leaned together, and looked down at the heart-drama
being acted below.{"\n"}{"\n"}
Long they sat thus. People surged along the sidewalk, crowding,
questioning, filling the air with rumours and inconsequent sur­
mises. Mrs. Murphy ploughed back and forth in their midst, like a
soft mountain down which plunged an audible cataract of tears.{"\n"}{"\n"}
Couriers came and went.{"\n"}{"\n"}
Loud voices and a renewed uproar were raised in front of the
boarding-house.{"\n"}{"\n"}
'What's up now, Judy?' asked Mr. McCaskey.{"\n"}{"\n"}
' 'Tis Missis Murphy's voice,' said Mrs. McCaskey, harking.{"\n"}{"\n"}
'She says she's after finding little Mike asleep behind the roll of
old linoleum under the bed in her room.'{"\n"}
Mr. McCaskey laughed loudly.{"\n"}{"\n"}
'That's yer Phelan,' he shouted sardonically 'Divil a bit would a
Pat have done that trick if the bye we never had is strayed and
stole, by the powers, call him Phelan, and see him hide out under
the bed like a mangy pup.'{"\n"}
Mrs. McCaskey arose heavily, and went toward the dish closet,
with the corners of her mouth drawn down.{"\n"}{"\n"}
Policeman Cleary came back around the corner as the crowd
dispersed. Surprised, he upturned an ear toward the McCaskey
apartment where the crash of irons and chinaware and the ring of
hurled kitchen utensils seemed as loud as before. Policeman
Cleary took out his timepiece.{"\n"}{"\n"}
'By the deported snakes!' he exclaimed, 'Jawn McCaskey and his
lady have been fightin' for an hour and a quarter by the watch.{"\n"}{"\n"}
The missis could give him forty pounds weight. Strength to his
arm.'{"\n"}
Policeman Cleary strolled back around the corner.{"\n"}{"\n"}
Old man Denny folded his paper and hurried up the steps just
as Mrs. Murphy was about to lock the door for the night.{"\n"}{"\n"}
  
        </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}

