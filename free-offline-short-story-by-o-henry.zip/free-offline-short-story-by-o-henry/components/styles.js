import React, { Component, PropTypes } from 'react';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo';

var styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
  },
  linearGradient: {
    // colors: ['#448AFF', '#9E9E9E', '#FFEB3B', '#FF5722']
    // colors: ['#A0FF70', '#4FE86E', '#3BFFE1', '#46AFE8', '#3158FF']
    colors: [ '#4FE86E', '#3BFFE1', '#46AFE8']
  },
  storyTitle:{
    margin: 38,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

module.exports = styles;