import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import styles from './styles'
import { LinearGradient } from 'expo';
import Ad from './Ad'

export default class Story8 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
        <LinearGradient colors={styles.linearGradient.colors} >
        <Text style={styles.storyTitle}>
          Memoirs of a Yellow Dog
       </Text>
        <Text style={styles.paragraph}>

I DON'T SUPPOSE it will knock any of you people off your perch to
read a contribution from an animal. Mr. Kipling and a good many
others have demonstrated the fact that animals can express them­
selves in remunerative English, and no magazine goes to press
nowadays without an animal story in it, except the old-style
monthlies that are still running pictures of Bryan and the Mont
Pelee horror.{"\n"}{"\n"}

But you needn't look for any stuck-up literature in my piece,
such as Bearoo, the bear, and Snakoo, the snake, and Tammanoo,
the tiger, talk in the jungle books. A yellow dog that's spent most
of his life in a cheap New York flat, sleeping in a corner on an old
sateen underskirt (the one she spilled port wine on at the Lady
Longshoremen's banquet), mustn't be expected to perform any
tricks with the art of speech.{"\n"}{"\n"}

I was born a yellow pup; date, locality, pedigree and weight
unknown. The first thing I can recollect, an old woman had me in
a basket at Broadway and Twenty-third trying to sell me to a
fat lady. Old Mother Hubbard was boosting me to beat the band
as a genuine Pomeranian-Hambletonian-Red-Irish-Cochin-ChinaStoke-Pogis fox terrier. The fat lady chased a V around among the
samples of gros grain flannelette in her shopping-bag till she cor­
nered it, and gave up. From that moment I was a pet - a mamma's
own wootsey squidlums. Say, gentle reader, did you ever have
a 200-pound woman breathing a flavour of Camembert cheese
and Peau d'Espagne pick you up and wallop her nose all over
you, remarking all the time in an Emma Eames tone of voice:
'Oh, oo's um oodlum, doodlum, woodlum, toodlum, bitsy-witsy
skoodlums?'
From a pedigreed yellow pup I grew up to be an anonymous
yellow cur looking like a cross between an Angora cat and a box of
lemons. But my mistress never tumbled. She thought that the two
primeval pups that Noah chased into the ark were but a collateral
branch of my ancestors. It took two policemen to keep her from
entering me at the Madison Square Garden for the Siberian
bloodhound prize.{"\n"}{"\n"}

I'll tell you about that flat. The house was the ordinary thing
in New York, paved with Parian marble in the entrance hall and
cobblestones above the first floor. Our flat was three fl - well,
not flights - climbs up. M y mistress rented it unfurnished, and
put in the regular things - 1903 antique upholstered parlour set,
oil chromo of geishas in a Harlem tea-house, rubber plant and
husband.{"\n"}{"\n"}

By Sirius! there was a biped I felt sorry for. He was a little man
with sandy hair and whiskers a good deal like mine. Hen-pecked?
- well, toucans and flamingoes and pelicans all had their bills in
him. He wiped the dishes and listened to my mistress tell about
the cheap, ragged things the lady with the squirrel-skin coat on
the second floor hung out on her line to dry. And every evening
while she was getting supper she made him take me out on the end
of a string for a walk.{"\n"}{"\n"}

If men knew how women pass the time when they are alone
they'd never marry. Laura Lean Jibbey, peanut brittle, a little
almond cream on the neck muscles, dishes unwashed, half an
hour's talk with the iceman, reading a package of old letters, a
couple of pickles and two bottles of malt extract, one hour peeking
through a hole in the window shade into the flat across the airshaft - that's about all there is to it. Twenty minutes before time
for him to come home from work she straightens up the house,
fixes her rat so it won't show, and gets out a lot of sewing for a
ten-minute bluff.{"\n"}{"\n"}

I led a dog's life in that flat. 'Most all day I lay there in my
corner watching the fat woman kill time. I slept sometimes and
had pipe dreams about being out chasing cats into basements and
growling at old ladies with black mittens, as a dog was intended to
do. Then she would pounce upon me with a lot of that drivelling
poodle palaver and kiss me on the nose - but what could I do? A
dog can't chew cloves.{"\n"}{"\n"}

I began to feel sorry for Hubby, dog my cats if I didn't. W e
looked so much alike that people noticed it when we went out; so
we shook the streets that Morgan's cab drives down, and took to
climbing the piles of last December's snow on the streets where
cheap people live.{"\n"}{"\n"}

One evening when we were thus promenading, and I was trying
to look like a prize St. Bernard, and the old man was trying to look
like he wouldn't have murdered the. first organ-grinder he heard
play Mendelssohn's wedding-march, I looked up at him and said,
in my way:
'What are you looking so sour about, you oakum trimmed lob­
ster? She don't kiss you. You don't have to sit on her lap and listen
to talk that would make the book of a musical comedy sound like
the maxims of Epictetus. You ought to be thankful you're not a
dog. Brace up, Benedick, and bid the blues begone.'{"\n"}

The matrimonial mishap looked down at me with almost canine
intelligence in his face.{"\n"}{"\n"}

'Why, doggie,' says he, 'good doggie. You almost look like you
could speak. What is it, doggie - Cats?'
Cats! Could speak!
But, of course, he couldn't understand. Humans were denied
the speech of animals. The only common ground of communica­
tion upon which dogs and men can get together is in fiction.{"\n"}{"\n"}

In the flat across the hall from us lived a lady with a black-andtan terrier. Her husband strung it and took it out every evening,
but he always came home cheerful and whistling. One day I
touched noses with the black-and-tan in the hall, and I struck him
for an elucidation.{"\n"}{"\n"}

'See, here, Wiggle-and-Skip,' I says, 'you know that it ain't the
nature of a real man to play dry-nurse to a dog in public. I never
saw one leashed to a bow-wow yet that didn't look like he'd like to
lick every other man that looked at him. But your boss comes in
every day as perky and set up as an amateur prestidigitator doing
the egg trick. How does he do it? Don't tell me he likes it.'{"\n"}

'Him?' says the black-and-tan. 'Why, he uses Nature's Own
Remedy. He gets spifflicated. At first when we go out he's as shy
as the man on the steamer who would rather play pedro when they
make 'em all jackpots. By the time we've been in eight saloons he
don't care whether the thing on the end of his line is a dog or a
catfish. I've lost two inches of my tail trying to sidestep those
swinging doors.'{"\n"}

The pointer I got from that terrier - vaudeville please copy - set
me to thinking.{"\n"}{"\n"}

One evening about six o'clock my mistress ordered him to get
busy and do the ozone act for Lovey. I have concealed it until
now, but that is what she called me. The black-and-tan was called
'Tweetness.' I consider that I have the bulge on him as far as you
could chase a rabbit. Still 'Lovey' is something of a nomenclatural
tin-can on the tail of one's self-respect.{"\n"}{"\n"}

At a quiet place on a safe street I tightened the line of my custo­
dian in front of an attractive, refined saloon. I made a dead-ahead
scramble for the doors, whining like a dog in the press despatches
that lets the family know that little Alice is bogged while gathering
lilies in the brook.{"\n"}{"\n"}

'Why, darn my eyes,' says the old man, with a grin; 'darn my
eyes if the saffron-coloured son of a seltzer lemonade ain't asking
me in to take a drink. Lemme see - how long's it been since I saved
shoe leather by keeping one foot on the footrest? I believe I'll - '
I knew I had him. Hot Scotches he took, sitting at a table. For
an hour he kept the Campbells coming. I sat by his side rapping
for the waiter with my tail, and eating free lunch such as mamma
in her flat never equalled with her homemade truck bought at a
delicatessen store eight minutes before papa comes home.{"\n"}{"\n"}

When the products of Scotland were all exhausted except the
rye bread the old man unwound me from the table leg and played
me outside like a fisherman plays a salmon. Out there he took off
my collar and threw it into the street.{"\n"}{"\n"}

'Poor doggie,' says he; 'good doggie. She shan't kiss you any
more. ' S a darned shame. Good doggie, go away and get run over
by a street car and be happy.'{"\n"}

I refused to leave. I leaped and frisked around the old man's legs
happy as a pug on a rug.{"\n"}{"\n"}

'You old flea-headed woodchuck-chaser,' I said to him - 'you
moon-baying, rabbit-pointing, egg-stealing old beagle, can't you
see that I don't want to leave you? Can't you see that we're both
Pups in the Wood and the missis is the cruel uncle after you with
the dish towel and me with the flea liniment and a pink bow to tie
on my tail. Why not cut that all out and be pards for evermore?'
Maybe you'll say he didn't understand - maybe he didn't. But
he kind of got a grip on the Hot Scotches, and stood still for a
minute, thinking.{"\n"}{"\n"}

'Doggie,' says he finally, 'we don't live more than a dozen lives
on this earth, and very few of us live to be more than 300. If I ever
see that flat any more I'm a flat, and if you do you're flatter; and
that's no flattery. I'm offering 60 to 1 that Westward Ho wins out
by the length of a dachshund.'{"\n"}

There was no string, but I frolicked along with my master to the
Twenty-third Street ferry. And the cats on the route saw reason to
give thanks that prehensile claws had been given them.{"\n"}{"\n"}

On the Jersey side my master said to a stranger who stood
eating a currant bun:
'Me and my doggie, we are bound for the Rocky Mountains.'{"\n"}

But what pleased me most was when my old man pulled both of
my ears until I howled, and said:
'You common, monkey-headed, rat-tailed, sulphur-coloured
son of a door-mat, do you know what I'm going to call you?'
I thought of 'Lovey,' and I whined dolefully.{"\n"}{"\n"}

'I'm going to call you "Pete," ' says my master; and if I'd had
five tails I couldn't have done enough wagging to do justice to the
occasion.
       </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}
