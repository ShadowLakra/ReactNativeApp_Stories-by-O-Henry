import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import { Actions, Router, Scene } from "react-native-router-flux";
import styles from './styles'
import { LinearGradient } from 'expo';
import Ad from './Ad'

export default class Story5 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
        <LinearGradient colors={styles.linearGradient.colors} >
        <Text style={styles.storyTitle}>
          The Coming-out of Maggie
       </Text>
        <Text style={styles.paragraph}>

EVERY SATURDAY NIGHT the Clover Leaf Social Club gave a hop
in the hall of the Give and Take Athletic Association on the East
Side. In order to attend one of these dances you must be a
member of the Give and Take - or, if you belong to the division
that starts off with the right foot in waltzing, you must work in
Rhinegold's paper-box factory. Still, any Clover Leaf was privi­leged to escort or be escorted by an outsider to a single dance. But mostly each Give and Take brought the paper-box girl that he affected; and few strangers could boast of having shaken a foot at the regular hops. {"\n"}{"\n"}

Maggie Toole, on account of her dull eyes, broad mouth and
left-handed style of footwork in the two-step, went to the dances
with Anna McCarty and her 'fellow.' Anna and Maggie worked
side by side in the factory, and were the greatest chums ever. So
Anna always made Jimmy Burns take her by Maggie's house every
Saturday night so that her friend could go to the dance with them.{"\n"}{"\n"}

The Give and Take Athletic Association lived up to its name. The
hall of the association in Orchard Street was fitted out with musclemaking inventions. With the fibres thus builded up the members
were wont to engage the police and rival social and athletic organiza­
tions in joyous combat. Between these more serious occupations the
Saturday night hops with the paper-box factory girls came as a refin­
ing influence and as an efficient screen. For sometimes the tip went
'round, and if you were among the elect that tiptoed up the dark back
stairway you might see as neat and satisfying a little welter-weight
affair to a finish as ever happened inside the ropes.{"\n"}{"\n"}

On Saturdays Rhinegold's paper-box factory closed at 3 p.m.' {"\n"}{"\n"}

On one such afternoon Anna and Maggie walked homeward
together. At Maggie's door Anna said, as usual: 'Be ready at seven,
sharp, Mag; and Jimmy and me'll come by for you.'{"\n"}

But what was this? Instead of the customary humble and grate­
ful thanks from the non-escorted one there was to be perceived a
high-poised head, a prideful dimpling at the corners of a broad
mouth, and almost a sparkle in a dull brown eye.{"\n"}{"\n"}

'Thanks, Anna,' said Maggie; 'but you and Jimmy needn't
bother to-night. I've a gentleman friend that's coming 'round to
escort me to the hop.'' {"\n"}

The comely Anna pounced upon her friend, shook her, chided
and beseeched her. Maggie Toole catch a fellow! Plain, dear,
loyal, unattractive Maggie, so sweet as a chum, so unsought for a
two-step or a moonlit bench in the little park. How was it? When
did it happen? Who was it?
'You'll see to-night,' said Maggie, flushed with the wine of the
first grapes she had gathered in Cupid's vineyard. 'He's swell all
right. He's two inches taller than Jimmy, and an up-to-date
dresser. I'll introduce him, Anna, just as soon as we get to the hall.'{"\n"}

Anna and Jimmy were among the first Clover Leafs to arrive
that evening. Anna's eyes were brightly fixed upon the door of the
hall to catch the first glimpse of her friend's 'catch.'' {"\n"}

At 8.30 Miss Toole swept into the hall with her escort. Quickly
her triumphant eye discovered her chum under the wing of her
faithful Jimmy.{"\n"}{"\n"}

'Oh, gee!' cried Anna, 'Mag ain't made a hit - oh, no! Swell
fellow? Well, I guess! Style? Look at 'um.'{"\n"}

'Go as far as you like,' said Jimmy, with sandpaper in his voice.{"\n"}{"\n"}

'Cop him out if you want him. These new guys always win out
with the push. Don't mind me. He don't squeeze all the limes, I
guess. Huh!'
'Shut up, Jimmy. You know what I mean. I'm glad for Mag.{"\n"}{"\n"}

First fellow she ever had. Oh, here they come.'{"\n"}

Across the floor Maggie sailed like a coquettish yacht convoyed
by a stately cruiser. And truly, her companion justified the
encomiums of the faithful chum. He stood two inches taller than
the average Give and Take athlete; his dark hair curled; his eyes
and his teeth flashed whenever he bestowed his frequent smiles.{"\n"}{"\n"}

The young men of the Clover Leaf Club pinned not their faith to
the graces of person as much as they did to its prowess, its
achievements in hand-to-hand conflicts, and its preservation from
the legal duress that constantly menaced it. The member of the
association who would bind a paper-box maiden to his conquering
chariot scorned to employ Beau Brummel airs. They were not
considered honourable methods of warfare. The swelling biceps,
the coat straining at its buttons over the chest, the air of conscious
conviction of the super-eminence of the male in the cosmogony of
creation, even a calm display of bow legs as subduing and enchant­
ing agents in the gentle tourneys of Cupid - these were the
approved arms and ammunition of the Clover Leaf gallants. They
viewed, then, the genuflexions and alluring poses of this visitor
with their chins at a new angle.{"\n"}{"\n"}

'A friend of mine, Mr. Terry O'Sullivan,' was Maggie's formula
of introduction. She led him around the room, presenting him to
each new-arriving Clover Leaf. Almost was she pretty now, with
the unique luminosity in her eyes that comes to a girl with her
first suitor and a kitten with its first mouse.{"\n"}{"\n"}

'Maggie Toole's got a fellow at last,' was the word that went
round among the paper-box girls. 'Pipe Mag's floor-walker' - thus
the Give and Takes expressed their indifferent contempt.{"\n"}{"\n"}

Usually at the weekly hops Maggie kept a spot on the wall warm
with her back. She felt and showed so much gratitude whenever a
self-sacrificing partner invited her to dance that his pleasure was
cheapened and diminished. She had even grown used to noticing
Anna joggle the reluctant Jimmy with her elbow as a signal for
him to invite her chum to walk over his feet through a two-step.{"\n"}{"\n"}

But to-night the pumpkin had turned to a coach and six. Terry
O'Sullivan was a victorious Prince Charming, and Maggie Toole
winged her first butterfly flight. And though our tropes of fairy­
land be mixed with those of entomology they shall not spill one
drop of ambrosia from the rose-crowned melody of Maggie's one
perfect night.{"\n"}{"\n"}

The girls besieged her for introductions to her 'fellow.' The
Clover Leaf young men, after two years of blindness, suddenly
perceived charms in Miss Toole. They flexed their compelling
muscles before her and bespoke her for the dance.{"\n"}{"\n"}

Thus she scored; but to Terry O'Sullivan the honours of the
evening fell thick and fast. He shook his curls; he smiled and went
easily through the seven motions for acquiring grace in your own
room before an open window ten minutes each day. He danced like
a faun; he introduced manner and style and atmosphere; his words
came trippingly upon his tongue, and - he waltzed twice in succes­
sion with the paper-box girl that Dempsey Donovan brought.{"\n"}{"\n"}

Dempsey was the leader of the association. He wore a dress suit,
and could chin the bar twice with one hand. He was one of 'Big
Mike' O'Sullivan's lieutenants, and was never troubled by trouble.' {"\n"}{"\n"}

No cop dared to arrest him. Whenever he broke a push-cart man's
head or shot a member of the Heinrick B. Sweeney Outing and
Literary Association in the kneecap, an officer would drop around
and say:
'The Cap'n'd like to see ye a few minutes round to the office
whin ye have time, Dempsey, me boy.' {"\n"}

But there would be sundry gentlemen there with large gold fob
chains and black cigars; and somebody would tell a funny story,
and then Dempsey would go back and work half an hour with the
six-pound dumb-bells. So, doing a tight-rope act on a wire
stretched across Niagara was a safe terpsichorean performance
compared with waltzing twice with Dempsey Donovan's paperbox girl. At ten o'clock the jolly round face of 'Big Mike' O'Sulli­
van shone at the door for five minutes upon the scene. He always
looked in for five minutes, smiled at the girls and handed out real
perfectos to the delighted boys.{"\n"}{"\n"}

Dempsey Donovan was at his elbow instantly, talking rapidly.{"\n"}{"\n"}

'Big Mike' looked carefully at the dancers, smiled, shook his head
and departed.{"\n"}{"\n"}

The music stopped. The dancers scattered to the chairs along
the walls. Terry O'Sullivan, with his entrancing bow, relinquished
a pretty girl in blue to her partner and started back to find
Maggie. Dempsey intercepted him in the middle of the floor.{"\n"}{"\n"}

Some fine instinct that Rome must have bequeathed to us
caused nearly every one to turn and look at them - there was a
subtle feeling that two gladiators had met in the arena. Two or
three Give and Takes with tight coat-sleeves drew nearer.{"\n"}{"\n"}

'One moment, Mr. O'Sullivan,' said Dempsey. 'I hope you're
enjoying yourself. Where did you say you lived?
The two gladiators were well matched. Dempsey had, perhaps,
ten pounds of weight to give away. The O'Sullivan had breadth
with quickness. Dempsey had a glacial eye, a dominating slit of a
mouth, an indestructible jaw, a complexion like a belle's and the
coolness of a champion. The visitor showed more fire in his con­
tempt and less control over his conspicuous sneer. They were ene­
mies by the law written when the rocks were molten. They were
each too splendid, too mighty, too incomparable to divide pre­
eminence. One only must survive.{"\n"}{"\n"}

'I live on Grand,' said O'Sullivan insolently; 'and no trouble to
find me at home. Where do you live?'
Dempsey ignored the question.{"\n"}{"\n"}

'You say your name's O'Sullivan,' he went on. 'Well, "Big
Mike" says he never saw you before.'" {"\n"}

'Lots of things he never saw,' said the favourite of the hop.{"\n"}{"\n"}

'As a rule,' went on Dempsey, huskily sweet, 'O'Sullivans in this
district know one another. You escorted one of our lady members
here, and we want a chance to make good. If you've got a family
tree let's see a few historical O'Sullivan buds come out on it. Or
do you want us to dig it out of you by the roots?'
'Suppose you mind your own business,' suggested O'Sullivan
blandly.{"\n"}{"\n"}

Dempsey's eyes brightened. He held up an inspired forefinger
as though a brilliant idea had struck him.{"\n"}{"\n"}

'I've got it now,' he said cordially. 'It was just a little mistake.{"\n"}{"\n"}

You ain't no O'Sullivan. You are a ring-tailed monkey. Excuse us
for not recognizing you at first.'' {"\n"}

O'Sullivan's eye flashed. He made a quick movement, but Andy
Geoghan was ready and caught his arm.{"\n"}{"\n"}

Dempsey nodded at Andy and William McMahan, the secretary of
the club, and walked rapidly toward a door at the rear of the hall.{"\n"}{"\n"}

Two other members of the Give and Take Association swiftly joined
the little group. Terry O'Sullivan was now in the hands of the Board
of Rules and Social Referees. They spoke to him briefly and softly,
and conducted him out through the same door at the rear.{"\n"}{"\n"}

This movement on the part of the Clover Leaf members
requires a word of elucidation. Back of the association hall was a
smaller room rented by the club. In this room personal difficulties
that arose on the ballroom floor were settled, man to man, with
the weapons of nature, under the supervision of the Board. No
lady could say that she had witnessed a fight at a Clover Leaf hop
in several years. Its gentlemen members guaranteed that.{"\n"}{"\n"}

So easily and smoothly had Dempsey and the Board done their
preliminary work that many in the hall had not noticed the check­
ing of the fascinating O'Sullivan's social triumph. Among these
was Maggie. She looked about for her escort.{"\n"}{"\n"}

'Smoke up!' said Rose Cassidy. 'Wasn't you on? Demps Dono­
van picked a scrap with your Lizzie-boy, and they've waltzed out
to the slaughter-room with him. How's my hair look done up this
way, Mag?'
Maggie laid a hand on the bosom of her cheesecloth waist.{"\n"}{"\n"}

'Gone to fight with Dempsey!' she said breathlessly. 'They've
got to be stopped. Dempsey Donovan can't fight him. Why, he'll he'll kill him!'
'Ah, what do you care?' said Rosa. 'Don't some of 'em fight
every hop?'
But Maggie was off, darting her zigzag way through the maze of
dancers. She burst through the rear door into the dark hall and
then threw her solid shoulder against the door of the room of
single combat. It gave way, and in the instant that she entered her
eye caught the scene - the Board standing about with open
watches; Dempsey Donovan in his shirt-sleeves dancing, lightfooted, with the wary grace of the modern pugilist, within easy
reach of his adversary; Terry O'Sullivan standing with arm folded
and a murderous look in his dark eyes. And without slacking the
speed of her entrance she leaped forward with a scream - leaped in
time to catch and hang upon the arm of O'Sullivan that was sud­
denly uplifted, and to whisk from it the long, bright stiletto that
he had drawn from his bosom.{"\n"}{"\n"}

The knife fell and rang upon the floor. Cold steel drawn in the
rooms of the Give and Take Association! Such a thing had never
happened before. Every one stood motionless for a minute. Andy
Geoghan kicked the stiletto with the toe of his shoe curiously, like
an antiquarian who has come upon some ancient weapon
unknown to his learning.{"\n"}{"\n"}

And then O'Sullivan hissed something unintelligible between
his teeth. Dempsey and the Board exchanged looks. And then
Dempsey looked at O'Sullivan without anger as one looks at a
stray dog, and nodded his head in the direction of the door.{"\n"}{"\n"}

'The back stairs, Giuseppi,' he said briefly. 'Somebody'll pitch
your hat down after you.'' {"\n"}

Maggie walked up to Dempsey Donovan. There was a brilliant
spot of red in her cheeks, down which slow tears were running.{"\n"}{"\n"}

But she looked him bravely in the eye.{"\n"}{"\n"}

'I knew it, Dempsey,' she said, as her eyes grew dull even in
their tears. 'I knew he was a Guinea. His name's Tony Spinelli. I
hurried in when they told me you and him was scrappin'. Them
Guineas always carries knives. But you don't understand,
Dempsey. I never had a fellow in my life. I got tired of comin'
with Anna and Jimmy every night, so I fixed it with him to call
himself O'Sullivan, and brought him along. I knew there'd be
nothin' doin' for him if he came as a Dago. I guess I'll resign from
the club now.'' {"\n"}

Dempsey turned to Andy Geoghan.{"\n"}{"\n"}

'Chuck that cheese slicer out of the window,' he said, 'and tell
'em inside that Mr. O'Sullivan has had a telephone message to go
down to Tammany Hall.'' {"\n"}

And then he turned back to Maggie.{"\n"}{"\n"}

'Say, Mag,' he said, 'I'll see you home. And how about next Sat­
urday night? Will you come to the hop with me if I call around for
you?'
It was remarkable how quickly Maggie's eyes could change from
dull to a shining brown.{"\n"}{"\n"}

'With you, Dempsey?' she stammered. 'Say - will a duck swim?'

        </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}

