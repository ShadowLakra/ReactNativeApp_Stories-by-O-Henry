import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import { AdMobBanner, AdMobInterstitial, PublisherBanner, AdMobRewarded} from 'expo';
import { LinearGradient } from 'expo';
import Ad from './Ad'
import styles from './styles'



export default class Info extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
      <LinearGradient colors={styles.linearGradient.colors} >
      <Text style={styles.storyTitle}>
          O. Henry
       </Text>
        <Text style={styles.paragraph}>
          William Sydney Porter (September 11, 1862 – June 5, 1910), better known by his pen name O. Henry, was an American short story writer. His stories are known for their surprise endings.
{"\n"}{"\n"}

          O. Henry's stories frequently have surprise endings. In his day he was called the American answer to Guy de Maupassant. While both authors wrote plot twist endings, O. Henry's stories were considerably more playful, and are also known for their witty narration.
{"\n"}{"\n"}
Most of O. Henry's stories are set in his own time, the early 20th century. Many take place in New York City and deal for the most part with ordinary people: policemen, waitresses, etc.
{"\n"}{"\n"}
O. Henry's work is wide-ranging, and his characters can be found roaming the cattle-lands of Texas, exploring the art of the con-man, or investigating the tensions of class and wealth in turn-of-the-century New York. O. Henry had an inimitable hand for isolating some element of society and describing it with an incredible economy and grace of language. Some of his best and least-known work is contained in Cabbages and Kings, a series of stories each of which explores some individual aspect of life in a paralytically sleepy Central American town, while advancing some aspect of the larger plot and relating back one to another.
{"\n"}{"\n"}
Cabbages and Kings was his first collection of stories, followed by The Four Million. The second collection opens with a reference to Ward McAllister's "assertion that there were only 'Four Hundred' people in New York City who were really worth noticing. But a wiser man has arisen—the census taker—and his larger estimate of human interest has been preferred in marking out the field of these little stories of the 'Four Million.'" To O. Henry, everyone in New York counted.
{"\n"}{"\n"}
He had an obvious affection for the city, which he called "Bagdad-on-the-Subway", and many of his stories are set there—while others are set in small towns or in other cities.
{"\n"}{"\n"}
His final work was "Dream", a short story intended for the magazine The Cosmopolitan but left incomplete at the time of his death.
{"\n"}{"\n"}
Among his most famous stories are:
{"\n"}
"The Gift of the Magi" is about a young couple, Jim and Della, who are short of money but desperately want to buy each other Christmas gifts. Unbeknownst to Jim, Della sells her most valuable possession, her beautiful hair, in order to buy a platinum fob chain for Jim's watch; while unbeknownst to Della, Jim sells his own most valuable possession, his watch, to buy jeweled combs for Della's hair. The essential premise of this story has been copied, re-worked, parodied, and otherwise re-told countless times in the century since it was written.{"\n"}{"\n"}
"The Ransom of Red Chief", in which two men kidnap a boy of ten. The boy turns out to be so bratty and obnoxious that the desperate men ultimately pay the boy's father $250 to take him back.{"\n"}{"\n"}
"The Cop and the Anthem" about a New York City hobo named Soapy, who sets out to get arrested so that he can be a guest of the city jail instead of sleeping out in the cold winter. Despite efforts at petty theft, vandalism, disorderly conduct, and "flirting" with a young prostitute, Soapy fails to draw the attention of the police. Disconsolate, he pauses in front of a church, where an organ anthem inspires him to clean up his life; ironically, he is charged for loitering and sentenced to three months in prison.{"\n"}{"\n"}
"A Retrieved Reformation", which tells the tale of safecracker Jimmy Valentine, recently freed from prison. He goes to a town bank to case it before he robs it. As he walks to the door, he catches the eye of the banker's beautiful daughter. They immediately fall in love and Valentine decides to give up his criminal career. He moves into the town, taking up the identity of Ralph Spencer, a shoemaker. Just as he is about to leave to deliver his specialized tools to an old associate, a lawman who recognizes him arrives at the bank. Jimmy and his fiancée and her family are at the bank, inspecting a new safe when a child accidentally gets locked inside the airtight vault. Knowing it will seal his fate, Valentine opens the safe to rescue the child. However, much to Valentine's surprise, the lawman denies recognizing him and lets him go.{"\n"}{"\n"}
"The Duplicity of Hargraves". A short story about a nearly destitute father and daughter's trip to Washington, D.C.{"\n"}{"\n"}
"The Caballero's Way", in which Porter's most famous character, the Cisco Kid, is introduced. It was first published in 1907 in the July issue of Everybody's Magazine and collected in the book Heart of the West that same year. In later film and TV depictions, the Kid would be portrayed as a dashing adventurer, perhaps skirting the edges of the law, but primarily on the side of the angels. In the original short story, the only story by Porter to feature the character, the Kid is a murderous, ruthless border desperado, whose trail is dogged by a heroic Texas Ranger. The twist ending is, unusually for Porter, tragic.

        </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}

