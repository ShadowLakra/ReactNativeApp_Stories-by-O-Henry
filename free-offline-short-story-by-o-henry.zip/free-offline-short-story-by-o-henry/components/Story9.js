import * as React from 'react';
import {ScrollView, Text, View, StyleSheet, Image } from 'react-native';
import { Actions, Router, Scene } from "react-native-router-flux";
import styles from './styles'
import { LinearGradient } from 'expo';
import Ad from './Ad'

export default class Story9 extends React.Component {
  render() {
    return (
      <ScrollView stickyHeaderIndices={[0]}>
      <Ad />
      <View style={styles.container}>
        <LinearGradient colors={styles.linearGradient.colors} >
        <Text style={styles.storyTitle}>
          The Love-philtre of Ikey Schoenstein
       </Text>
        <Text style={styles.paragraph}>


THE BLUE LIGHT DRUG STORE is down-town, between the Bowery

and First Avenue, where the distance between the two streets is the
shortest. The Blue Light does not consider that pharmacy is a thing
of bric-a-brac, scent and ice-cream soda. If you ask it for a pain-killer
it will not give you a bonbon.{"\n"}{"\n"}

The Blue Light scorns the labour-saving arts of modern phar­
macy. It macerates its opium and percolates its own laudanum and
paregoric. To this day pills are made behind its tall prescription
desk - pills rolled out on its own pill-tile, divided with a spatula,
rolled with the finger and thumb, dusted with calcined magnesia
and delivered in little round, pasteboard pill-boxes. The store is on
a corner about which coveys of ragged-plumed, hilarious children
play and become candidates for the cough-drops and soothing
syrups that wait for them inside.{"\n"}{"\n"}

Ikey Schoenstein was the night clerk of the Blue Light and the
friend of his customers. Thus it is on the East Side, where the
heart of pharmacy is not glace. There, as it should be, the druggist
is a counsellor, a confessor, an adviser, an able and willing mis­
sionary and mentor whose learning is respected, whose occult
wisdom is venerated and whose medicine is often poured,
untasted, into the gutter. Therefore Ikey's corniform, bespecta­
cled nose and narrow, knowledge-bowed figure was well known in
the vicinity of the Blue Light, and his advice and notice were
much desired.{"\n"}{"\n"}

Ikey roomed and breakfasted at Mrs. Riddle's, two squares
away. Mrs. Riddle had a daughter named Rosy. The circumlocu­
tion has been in vain - you must have guessed it - Ikey adored
Rosy. She tinctured all his thoughts; she was the compound
extract of all that was chemically pure and officinal - the dispen­
satory contained nothing equal to her. But Ikey was timid, and his
hopes remained insoluble in the menstruum of his backwardness
and fears. Behind his counter he was a superior being, calmly
conscious of special knowledge and worth; outside, he was a
weak-kneed, purblind, motorman-cursed rambler, with ill-fitting
clothes stained with chemicals and smelling of socotrine aloes and
valerianate of ammonia.{"\n"}{"\n"}

The fly in Ikey's ointment (thrice welcome, pat trope!) was
Chunk McGowan.{"\n"}{"\n"}

Mr. McGowan was also striving to catch the bright smiles
tossed about by Rosy. But he was no out-fielder as Ikey was; he
picked them off the bat. At the same time he was Ikey's friend and
customer, and often dropped in at the Blue Light Drug Store to
have a bruise painted with iodine or get a cut rubber-plastered
after a pleasant evening spent along the Bowery.{"\n"}{"\n"}

One afternoon McGowan drifted in in his silent, easy way, and
sat, comely, smoothed-faced, hard, indomitable, good-natured,
upon a stool.{"\n"}{"\n"}

'Ikey,' said he, when his friend had fetched his mortar and sat
opposite, grinding gum benzoin to a powder, 'get busy with your
ear. It's drugs for me if you've got the line I need.'{"\n"}

Ikey scanned the countenance of Mr. McGowan for the usual
evidences of conflict, but found none.{"\n"}{"\n"}

'Take your coat off,' he ordered. 'I guess already that you have
been stuck in the ribs with a knife. I have many times told you
those Dagoes would do you up.'{"\n"}

Mr. McGowan smiled. 'Not them,' he said. 'Not any Dagoes.{"\n"}{"\n"}

But you've located the diagnosis all right enough - it's under my
coat, near the ribs. Say! Ikey - Rosy and me are goin' to run away
and get married to-night.'{"\n"}

Ikey's left forefinger was doubled over the edge of the mortar,
holding it steady. He gave it a wild rap with the pestle, but felt
it not. Meanwhile Mr. McGowan's smile faded to a look of
perplexed gloom.{"\n"}{"\n"}

'That is,' he continued, 'if she keeps in the notion until the time
comes. We've been layin' pipes for the gateway for two weeks.{"\n"}{"\n"}

One day she says she will; the same evenin' she says nixy. We've
agreed on to-night, and Rosy's stuck to the affirmative this time
for two whole days. But it's five hours yet till the time, and I'm
afraid she'll stand me up when it comes to the scratch.'{"\n"}

'You said you wanted drugs,' remarked Ikey.{"\n"}{"\n"}

Mr. McGowan looked ill at ease and harassed - a condition
opposed to his usual line of demeanour. He made a patent-medi­
cine almanac into a roll and fitted it with unprofitable carefulness
about his finger.{"\n"}{"\n"}

'I wouldn't have this double handicap make a false start to-night
for a million,' he said. 'I've got a little flat up in Harlem all ready,
with chrysanthemums on the table and a kettle ready to boil. And
I've engaged a pulpit pounder to be ready at his house for us at
9.30. It's got to come off. And if Rosy don't change her mind
again!' - Mr. McGowan ceased, a prey to his doubts.{"\n"}{"\n"}

'I don't see then yet,' said Ikey shortly, 'what makes it that you
talk of drugs, or what I can be doing about it.'{"\n"}

'Old man Riddle don't like me a little bit,' went on the uneasy
suitor, bent upon marshalling his arguments. 'For a week he hasn't
let Rosy step outside the door with me. If it wasn't for losin' a
boarder they'd have bounced me long ago. I'm makin' $20 a week
and she'll never regret flyin' the coop with Chunk McGowan.'{"\n"}

'You will excuse me, Chunk,' said Ikey. 'I must make a prescription
that is to be called for soon.'{"\n"}

'Say,' said McGowan, looking up suddenly, 'say, Ikey, ain't
there a drug of some kind - some kind of powders that'll make a
girl like you better if you give 'em to her?'
Ikey's lip beneath his nose curled with the scorn of superior
enlightenment; but before he could answer, McGowan continued:
'Tim Lacy told me once that he got some from a croaker up­
town and fed 'em to his girl in soda water. From the very first dose
he was ace-high and everybody else looked like thirty cents to her.{"\n"}{"\n"}

They was married in less than two weeks.'{"\n"}

Strong and simple was Chunk McGowan. A better reader of
men than Ikey was could have seen that his tough frame was
strung upon fine wires. Like a good general who was about to
invade the enemy's territory he was seeking to guard every point
against possible failure.{"\n"}{"\n"}

'I thought,' went on Chunk hopefully, 'that if I had one of them
powders to give Rosy when I see her at supper to-night it might
brace her up and keep her from reneging on the proposition to
skip. I guess she don't need a mule team to drag her away, but
women are better at coaching than they are at running bases. If
the stuff'll work just for a couple of hours it'll do the trick.'{"\n"}

'When is this foolishness of running away to be happening?'
asked Ikey.{"\n"}{"\n"}

'Nine o'clock,' said Mr. McGowan. 'Supper's at seven. At eight
Rosy goes to bed with a headache. At nine old Parvenzano lets me
through to his backyard, where there's a board off Riddle's fence,
next door. I go under her window and help her down the fireescape. We've got to make it early on the preacher's account. It's
all dead easy if Rosy don't balk when the flag drops. Can you fix
me one of them powders, Ikey?'
Ikey Schoenstein rubbed his nose slowly.{"\n"}{"\n"}

'Chunk,' said he, 'it is of drugs of that nature that pharma­
ceutists must have much carefulness. To you alone of my acquain­
tance would I entrust a powder like that. But for you I shall make
it, and you shall see how it makes Rosy to think of you.'{"\n"}

Ikey went behind the prescription desk. There he crushed to a
powder two soluble tablets, each containing a quarter of a grain of
morphia. To them he added a little sugar of milk to increase the
bulk, and folded the mixture neatly in a white paper. Taken by an
adult this powder would ensure several hours of heavy slumber
without danger to the sleeper. This he handed to Chunk
McGowan, telling him to administer it in a liquid, if possible, and
received the hearty thanks of the backyard Lochinvar.{"\n"}{"\n"}

The subtlety of Ikey's action becomes apparent upon recital of
his subsequent move. He sent a messenger for Mr. Riddle and dis­
closed the plans of McGowan for eloping with Rosy. Mr. Riddle
was a stout man, brick-dusty of complexion and sudden in action.{"\n"}{"\n"}

'Much obliged,' he said briefly to Ikey. 'The lazy Irish loafer!
My own room's just above Rosy's, I'll just go up there myself after
supper and load the shot-gun and wait. If he comes in my back­
yard he'll go away in an ambulance instead of a bridal chaise.'{"\n"}

With Rosy held in the clutches of Morpheus for a manyhours' deep slumber, and the bloodthirsty parent waiting, armed
and forewarned, Ikey felt that his rival was close, indeed, upon
discomfiture.{"\n"}{"\n"}

All night in the Blue Light Store he waited at his duties for
chance news of the tragedy, but none came.{"\n"}{"\n"}

At eight o'clock in the morning the day clerk arrived and Ikey
started hurriedly for Mrs. Riddle's to learn the outcome. And, lo!
as he stepped out of the store who but Chunk McGowan sprang
from a passing street-car and grasped his hand - Chunk McGowan
with a victor's smile and flushed with joy.{"\n"}{"\n"}

'Pulled it off,' said Chunk with Elysium in his grin. 'Rosy hit the
fire-escape on time to a second and we was under the wire at the
Reverend's at 9 . 3 0 / . She's up at the flat - she cooked eggs this
mornin' in a blue kimono - Lord! how lucky I am! You must pace
up some day, Ikey, and feed with us. I've got a job down near the
bridge, and that's where I'm heading for now.'{"\n"}

'The - the powder?' stammered Ikey.{"\n"}{"\n"}

'Oh, that stuff you gave me!' said Chunk broadening his grin;
'well, it was this way. I sat down at the supper table last night at
Riddle's, and I looked at Rosy, and I says to myself, "Chunk, if you
get the girl get her on the square - don't try any hocus-pocus with
a thoroughbred like her." And I keeps the paper you give me in
my pocket. And then my lamps falls on another party present,
who, I says to myself, is failin' in a proper affection toward his
comin' son-in-law, so I watches my chance and dumps that
powder in old man Riddle's coffee - see?'
1
4
moment immovable. For this odour belonged to Miss Leslie; it
was her own, and hers only.{"\n"}{"\n"}

The odour brought her vividly, almost tangibly before him. The
world of finance dwindled suddenly to a speck. And she was in the
next room - twenty steps away.{"\n"}{"\n"}

'By George, I'll do it now,' said Maxwell, half aloud. 'I'll ask her
now. I wonder I didn't do it long ago.'{"\n"}

He dashed into the inner office with the haste of a short trying
to cover. He charged upon the desk of the stenographer.{"\n"}{"\n"}

She looked up at him with a smile. A soft pink crept over her
cheek, and her eyes were kind and frank. Maxwell leaned one
elbow on her desk. He still clutched fluttering papers with both
hands and the pen was above his ear.{"\n"}{"\n"}

'Miss Leslie,' he began hurriedly, 'I have but a moment to spare.{"\n"}{"\n"}

I want to say something in that moment. Will you be my wife? I
haven't had time to make love to you in the ordinary way, but I
really do love you. Talk quick, please - those fellows are clubbing
the stuffing out of Union Pacific'
'Oh, what are you talking about?' exclaimed the young lady. She
rose to her feet and gazed upon him, round-eyed.{"\n"}{"\n"}

'Don't you understand?' said Maxwell restively. 'I want you to
marry me. I love you, Miss Leslie. I wanted to tell you, and I
snatched a minute when things had slackened up a bit. They're
calling me for the 'phone now. Tell 'em to wait a minute, Pitcher.{"\n"}{"\n"}

Won't you, Miss Leslie?'
The stenographer acted very queerly. At first she seemed over­
come with amazement; then tears flowed from her wondering
eyes; and then she smiled sunnily through them, and one of her
arms slid tenderly about the broker's neck.{"\n"}{"\n"}

'I know now,' she said softly. 'It's this old business that has
driven everything else out of your head for the time. I was fright­
ened at first. Don't you remember, Harvey? We were married
last evening at eight o'clock in the Little Church Around the
Corner.'
       </Text>
        </LinearGradient>
      </View>
      </ScrollView>
    );
  }
}